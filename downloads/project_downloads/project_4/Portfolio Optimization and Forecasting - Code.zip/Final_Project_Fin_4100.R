
# Final Project Script
#===============================================================================
# Culmination of our efforts.

#===============================================================================
# Packages
#===============================================================================
# You will need the below packages to run the entire script, openxlsx is optional,
# however, it's recommended if you wish to export any of the tables with the existing script.

# Packages we need
Packages = c("tidyverse", "lubridate", "openxlsx", "urca", "rugarch", "xts")

# This will load and install the packages if required
PackagesCheck = lapply(
  Packages,
  FUN = function(x) {
    if (!require(x, character.only = TRUE)) {
        install.packages(x, dependicies = TRUE)
        library(x, character.only = TRUE)
    }p[]
  }
)

# Clean up
rm(Packages, PackagesCheck)


#===============================================================================
# Functions
#===============================================================================

# Excel Functions

Excel_Import = function(FileDir = FileDir) {
  # This function takes our FileDir list and uses it to import all our csv's
  
  # Variables
  List = vector(mode = "list", length = length(FileDir)) # Creating a blank list to store our imports
  skip = c(0,0,4,0) # Need to skip 4 rows for french's data to avoid an error
  
  # For Loop - Iterates over FileDir and pulls each file from my directory.
  for (i in 1:length(FileDir)) {
    List[[i]] = as.data.frame(read.csv(file = FileDir[[i]], skip = skip[i]))
  }
  
  # End of Function
  return(List)
  
}

Excel_Export = function(FileExport = FileExport, Directory = Dir, FileName = "Assignment One Data.xlsx") {
  # This function Writes data.frames (most formats should work) to excel
  
  # Variables
  wb = createWorkbook(,title = FileName) # This is setting up a workbook in our environment to write to.
  
  # For Loop - Iterates over FileExport, adds a worksheet to workbook, writes our data.
  for (i in 1:length(FileExport)) {
    addWorksheet(wb, sheetName = names(FileExport)[i])
    writeDataTable(wb,sheet = names(FileExport)[[i]], FileExport[[i]], rowNames = TRUE)
  }
  
  # End of Function - Saves our workbook to our directory.
  saveWorkbook(wb, file = paste0(Directory,FileName))
  
}

# Calculation Functions
#   - These are functions I wrote from scratch

Calculate_Returns = function(ClosePrice = CombinedData) {
  # This function calculates the return and log return for each close price
  
  # Variables
  ClosePriceLag = rbind(rep(NA, ncol(ClosePrice)), head(ClosePrice, -1))
  CloseIndex = which(grepl("Close", colnames(ClosePrice)) == TRUE) # Returns which columns are the closing prices.
  
  # Calculate Returns
  Return = (ClosePrice[,CloseIndex] - ClosePriceLag[,CloseIndex]) / ClosePriceLag[,CloseIndex]
  ReturnLog = log(ClosePrice[,CloseIndex]) - log(ClosePriceLag[,CloseIndex])
  Gross = ClosePrice[,CloseIndex] / ClosePriceLag[,CloseIndex]
  
  # Rename Columns
  colnames(Return) = gsub("Close", "Return", colnames(Return))
  colnames(ReturnLog) = gsub("Close", "Return.Log", colnames(ReturnLog))
  colnames(Gross) = gsub("Close", "Gross", colnames(Gross))
  
  # Combine Original Data and Returns into one data.frame
  Returns = cbind(ClosePrice, Gross, Return, ReturnLog)
  
  # End of Function
  return(Returns)
}

Calculate_Measures = function(VariousReturns = CombinedData, k = 252) {
  # This function will subset for returns and calculate Mean, SD, and Variance 
  # for daily and yearly times.
  
  # Variables
  ReturnIndex = which(grepl("Return|RF", colnames(VariousReturns)) == TRUE) # Returns which columns are the closing prices.
  VariousReturns = VariousReturns[,ReturnIndex] # Masks for columns using ReturnIndex
  Measures = c(mean, sd, var) # The measures we wish to apply to each return
  MeasuresNames = c("Mean", "StandardDeviation", "Variance") # For referencing in the later 'if' statement
  
  # Sub Functions
  ApplyMeasures = function(fun, Column, na_rm = TRUE){
    # This function applys a function onto a column
    
    return(fun(Column,na.rm = na_rm))
    
  }
  
  Annualized = function(x, type = "Mean", k = 1) {
    # This function actualizes any returns.
    
    # If statement to figure out how we want to annualize based on the measure.
    if (type == "Mean") {
      R = ((x+1)^(1/((1/k))))-1
      
    } else if (type == "StandardDeviation") {
      R = x*sqrt(k)
      
    } else if (type == "Variance") {
      R = x*k
      
    } else {
      return(stop("Something is Wrong :("))
      
    }
    
    # End of Function
    return(as.list(R)) 
    
  }
  
  # Measures Daily - apply() Measures list over our Index for our VariousReturns columns.
  MeasuresDaily = lapply(Measures, function(x) apply(VariousReturns, 2, function(y) ApplyMeasures(fun = x, Column = y)))
  names(MeasuresDaily) = paste0("Daily.",MeasuresNames)
  
  # Measures Yearly - mapply() iterates over MeasuresDaily and Measures name to annualize every measure.
  MeasuresYearly = mapply(function(x, y) Annualized(x, y, k), x = MeasuresDaily, y = MeasuresNames, SIMPLIFY = TRUE) # For this function to work, MeasuresDaily needs to be in a list.
  colnames(MeasuresYearly)=paste0("Yearly.",MeasuresNames)
  
  # Formatting - Making sure it's the proper format.
  MeasuresDaily = do.call(cbind, MeasuresDaily) # Combine MeasuresDaily into a data.frame
  AllMeasures = cbind(MeasuresDaily, MeasuresYearly) %>% as.data.frame() # Combine both Daily and Yearly Measures
  rownames(AllMeasures) = gsub("(Return)\\.", "", rownames(AllMeasures), perl = TRUE) # Fix rownames to be correct.
  
  AllMeasures = sapply(AllMeasures, function(x) unlist(x)) %>%  as.data.frame() # Each column is actually a list now, so this fixes it.
  
  # End of Function
  return(AllMeasures)
  
}

Calculate_SharpeRatios = function(DailyYearlyMeasures = A1.DailyYearlyMeasures) {
  # This calculates the Sharpe ratio using vectors
  
  # Variables - Index for Daily and Yearly means and standard deviations.
  ReturnIndex = grepl("Daily.Mean", colnames(DailyYearlyMeasures)) # Index for each mean column
  ReturnDaily = tail(DailyYearlyMeasures[,ReturnIndex], -1) # Removing the RF row
  
  ReturnIndex = grepl("Yearly.Mean", colnames(DailyYearlyMeasures)) # Index for each mean column
  ReturnYearly = tail(DailyYearlyMeasures[,ReturnIndex], -1)# Removing the RF row
  
  StandardDeviationIndex = grepl("Daily.StandardDeviation", colnames(DailyYearlyMeasures)) # Index for each StandardDeviation column
  StandardDeviationDaily = tail(DailyYearlyMeasures[,StandardDeviationIndex], -1) # Removing the RF row
  
  StandardDeviationIndex = grepl("Yearly.StandardDeviation", colnames(DailyYearlyMeasures)) # Index for each StandardDeviation column
  StandardDeviationYearly = tail(DailyYearlyMeasures[,StandardDeviationIndex], -1) # Removing the RF row
  
  RiskFreeDaily = DailyYearlyMeasures[1,grepl("Daily.Mean", colnames(DailyYearlyMeasures))] # Grabing the RiskFree daily, which should be in the first row
  RiskFreeYearly = DailyYearlyMeasures[1,grepl("Yearly.Mean", colnames(DailyYearlyMeasures))] # Grabing the RiskFree daily, which should be in the first row

  # Calculate the SharpeRatio
  SharpeRatiosDaily = (ReturnDaily - RiskFreeDaily) / StandardDeviationDaily # Calculating the sharpe ratio for daily returns
  SharpeRatiosYearly = (ReturnYearly - RiskFreeYearly) / StandardDeviationYearly # Calculatin the sharpe ratio for yearly returns.
  
  SharpeRatios = matrix(c(SharpeRatiosDaily, SharpeRatiosYearly), nrow = length(SharpeRatiosDaily), ncol = 2) %>% as.data.frame # Combining all my ratio together
  colnames(SharpeRatios) = c("Daily.SharpeRatios", "Yearly.SharpeRatios") 
  rownames(SharpeRatios) = DailyYearlyMeasures[-1,] %>% rownames() # to name the rows I need ot make sure to get rid of the risk free row name
  
  # End of Function
  return(SharpeRatios)
  
}

Create_Equal_Portfolio = function(Data = CombinedData, weight = 0.5) {
  # This function takes our dataset and returns a matrix containing the returns
  # for each asset return split equally with our risk free rate.
  
  # Variables
  Returns = Data[, grepl("Return", colnames(Data))]
  RiskFree = Data[,"RF"]
  
  # Calculate
  EqualPortfolio = (Returns*weight) + (RiskFree*(1-weight))
  
  # Add Date Column
  EqualPortfolio = cbind(Data$Date, EqualPortfolio)
  colnames(EqualPortfolio)[1] = "Date"
  
  # Rename Columns
  colnames(EqualPortfolio) = gsub("Return\\.", "Return.Equal.", colnames(EqualPortfolio))
  
  # End of Function
  return(EqualPortfolio)
  
}

Create_OMV_Portfolio = function(Data = CombinedData, Measures = A1.DailyYearlyMeasures, k = 1) {
  # This function creates weights using data and K values
  
  # Variables
  RiskFree = Data[, grepl("RF", colnames(Data))]
  
  Returns = Measures[, grepl("Mean$", colnames(Measures))]
  Returns = Returns[grepl("Return", rownames(Returns)),]
  
  StandardDeviations = Measures[,grepl("StandardDeviation$", colnames(Measures))]
  StandardDeviations = StandardDeviations[grepl("Return", rownames(StandardDeviations)),]
  
  # Check
  if(all.equal(rownames(StandardDeviations), colnames(Returns)) == FALSE){
    stop("standard deviation row names do not match return column names")
  }
  
  # Calculation
  # I'll do it in three separate steps
  #   1. Do Asset Returns - RiskFree
  #   2. Divide by respective standard deviation
  #   3. multiply by 1/k
  
  Step1 = apply(Returns, 1, function(x) -(RiskFree - x[1]))
    # x[1] is used to index our daily mean returns
  
  Step2 = sweep(Step1, 2, StandardDeviations[,1], FUN = '/')
    # StandardDeviatons[,1] indexes for daily standard deviation
    # sweep() allows us to divide each column by the respective standard deviation
  
  Step3 = Step2 * 1/k # Apply our k value
  
  # Rename Columns
  colnames(Step3) = gsub("Return", "Return\\.Weight", colnames(Step3))
  
  # End of Function
  return(as.data.frame(Step3))
  
}

Apply_OMV_Weights = function(RiskyWeight = A2.OMVPortfolioWeights, Returns = CombinedData) {
  # This function applies our weights onto our returns and the risk free return
  
  # Variables
  RiskFreeWeight = 1 - RiskyWeight # Just the complement of our risky weights
  
  # Returns
  RiskyReturns = Returns[,grepl("Return", colnames(Returns))] * RiskyWeight
  RiskFreeReturns = Returns[,grepl("RF", colnames(Returns))] * RiskFreeWeight
  PortfolioReturn = RiskyReturns + RiskFreeReturns
  
  # End of function
  return(PortfolioReturn)
}

# Wrapper Functions
#   - These are functions wrapped around a given function (ARIMA, DF, ACF,...)

Run_DF_Test = function(VectorName, lags, type) {
  # This function wraps around the ur.af function from urca
  
  Vector = CombinedData %>% select(VectorName)
  Vector = Vector[!is.na(Vector), ]
  
  ADF_Tests = vector(mode = "list", length(lags)+1)
  
  for (i in 1:length(lags)) {
    ADF_Tests[[i]] = ur.df(Vector, lags = lags[i], type = type, selectlags = c("Fixed"))
  }
  
  ADF_Tests[[length(ADF_Tests)]] =  ur.df(Vector, type = type, selectlags = c("AIC"))
  
  
  return(ADF_Tests)
  
}

Run_ACF_PACF_Ljung = function(Vector, Max_Lags){
  # This function recieves a list of vectors and respective max lags to calculate
  # ACF, PACF, and Ljung pvalues
  
  # ACF and PACF
  ACF = mapply(function(x,y) acf(unlist(x), lag.max = y), x = Vector, y = Max_Lags, SIMPLIFY = FALSE)
  PACF = mapply(function(x,y) acf(unlist(x),type = "partial", lag.max = y), x = Vector, y = Max_Lags, SIMPLIFY = FALSE)
  
  # Ljung Test
  #   - Setup a blank matrix
  #   - repeat test for 1:5 lags
  #   - format Ljung object into a table containing only p=values
  
  Ljung.pvalues = matrix(,0,5) # column for each lag (I transpose later)
  
  for( i in 1:5) {
    # For loop to apply Ljung to different lags
    
    Ljung = lapply(Vector, function(x) Box.test(unlist(x), lag = i, type = "Ljung-Box", fitdf = 0))
    Ljung.pvalues = append(Ljung.pvalues, t(unlist(mapply("[", Ljung)[3,])))
    rm(Ljung)
    
  }
  
  # Format
  Ljung.pvalues = t(matrix(Ljung.pvalues,length(Max_Lags),5))
  colnames(Ljung.pvalues) = names(Vector)
  
  # List Our three variables
  A4.ACF.PACF.Ljung = list(ACF
                           , PACF
                           , Ljung.pvalues
  )
  
  # End of Function
  return(A4.ACF.PACF.Ljung)
}

Run_ARIMA = function(Vector, diff) {
  # Setup empty list for all our models
  Models = vector("list", length(Vector)) # setup empty list for each vector
  Models = lapply(Models, function(x) vector("list", 5*5)) # setup empty lists for each model
  
  # Run ARIMA function in a loop for various p and q numbers
  for (i in 1:length(Vector)) {
    Index = 1
    print(paste("Starting...", names(Vector)[Index]))
    
    for (p in 1:5) {
      for(q in 1:5) {
        
        print(paste(i,p,q))
        
        model = arima(Vector[[i]], c(p,diff[i],q), method = "ML")
        order = paste(p,diff[i],q)
        
        Models[[i]][[Index]] = list(model,order)
        
        Index = Index + 1
        
      }
    }
  }
  
  # Name list at index 1
  names(Models) = names(Vector)
  
  # End of Function
  return(Models)
}

Run_AIC_BIC = function(Models) {
  # This function runs the AIC and BIC calculations for our ARIMA models in Assignment 4.
  
  # AIC
  AIC = lapply(Models, function(x) sapply(x, function(y) AIC(y[[1]])))
  AIC = do.call(rbind, AIC)
  AIC.MIN = apply(AIC, 1, function(x) min(x))
  AIC.MIN.Index = apply(AIC, 1, function(x) which(x == min(x)))
  
  # BIC
  BIC = lapply(Models, function(x) sapply(x, function(y) AIC(y[[1]], k = log(length(y[[1]]$residuals)))))
  BIC = do.call(rbind, BIC)
  BIC.MIN = apply(BIC, 1, function(x) min(x))
  BIC.MIN.Index = apply(BIC, 1, function(x) which(x == min(x)))
  
  # Create Lists for Both
  AIC_List = list(AIC
                  , AIC.MIN
                  , AIC.MIN.Index
  )
  names(AIC_List) = c("Result", "Min", "Index")
  
  
  BIC_list = list(BIC
                  , BIC.MIN
                  , BIC.MIN.Index
  )
  names(BIC_list) = c("Result", "Min", "Index")
  
  # Combine Lists
  AIC.BIC = list(AIC_List, BIC_list)
  names(AIC.BIC) = c("AIC", "BIC")
  
  
  
  # End of Function
  return(AIC.BIC)
}

Run_AIC_BIC_2 = function(Models) {
  # This function runs the AIC and BIC calculations for our GARCH models in Assignment 5.
  
  # AIC
  AIC = lapply(Models, function(x) sapply(x, function(y) infocriteria(y[[1]])[1,1]))
  AIC = do.call(rbind, AIC)
  AIC.MIN = apply(AIC, 1, function(x) min(x))
  AIC.MIN.Index = apply(AIC, 1, function(x) which(x == min(x)))
  
  # BIC
  BIC = lapply(Models, function(x) sapply(x, function(y) infocriteria(y[[1]])[2,1]))
  BIC = do.call(rbind, BIC)
  BIC.MIN = apply(BIC, 1, function(x) min(x))
  BIC.MIN.Index = apply(BIC, 1, function(x) which(x == min(x)))
  
  # Create Lists for Both
  AIC_List = list(AIC
                  , AIC.MIN
                  , AIC.MIN.Index
  )
  names(AIC_List) = c("Result", "Min", "Index")
  
  
  BIC_list = list(BIC
                  , BIC.MIN
                  , BIC.MIN.Index
  )
  names(BIC_list) = c("Result", "Min", "Index")
  
  # Combine Lists
  AIC.BIC = list(AIC_List, BIC_list)
  names(AIC.BIC) = c("AIC", "BIC")
  
  # End of Function
  return(AIC.BIC)
  
}

# Plotting Functions
#   - These function help me plot my data structures easier

GroupByKey = function(x, KeyName = "Return") {
  # This function converts our data into long format by a ke
  
  # Variables
  Colnames = colnames(x[,grepl(KeyName, colnames(x))])
  
  # Convert Data
  PlotingData = gather(x, Key, Key.Value, Colnames)
  PlotingData = PlotingData[order(PlotingData$Key),]
  
  # Column Names
  colnames(PlotingData) = c("Date", paste0(KeyName, ".Asset"), KeyName)
  
  # End of Function
  return(PlotingData)
  
}

PlotbyList = function(PlotData, x, y, color, title, index) {
  # This function takes in long data in a list and creates/exports graphs
  
  gtitle = paste0(title,index)
  gxtitle = paste0("Plot - ",title,index, ".png")
  
  Plot = ggplot(data = PlotData, mapping = aes_string(x = x, y = y, color = color)) +
    geom_point(size = 0.5) +
    geom_line(size = 0.5) +
    ggtitle(gtitle)
  
  paste0("Printing ", gxtitle, "...") %>% print()
  PlotData %>% head %>% print
  
  ggsave(device = "png", plot = Plot, filename = gxtitle)
  
}

PlotResidualsSquared = function(data, names) {
  # This function plots and exports residuals^2 in my lists
  
  
  title = paste0("Residual^2 ",names)
  
  Plot = ggplot(data, aes(x = date, y = residual)) +
    geom_bar(stat='identity', width = 1.5) +
    ggtitle(title)
  
  
  ggsave(device = "png", plot = Plot, filename = paste0("Residual ", names, ".png"))
  
}

#===============================================================================
# Directories
#===============================================================================
# Below is the data you will need to run this file.
#   - "ENB" : from yahoo finance for ENB (NYSE), https://finance.yahoo.com/quote/ENB/history?period1=448156800&period2=1642464000&interval=1d&filter=history&frequency=1d&includeAdjustedClose=true
#   - "MSFT" : from yahoo finance for MSFT(NasdaqG5), https://finance.yahoo.com/quote/MSFT/history?period1=511056000&period2=1642636800&interval=1d&filter=history&frequency=1d&includeAdjustedClose=true
#   - "F-F_Research_Data_Factors_Daily.CSV" : from Ken French's site download link for "Fama/French 3 Factors [Daily]", http://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html
#   - "oxfordmanrealizedvolatilityindices.csv" : from https://realized.oxford-man.ox.ac.uk/data/download, the top download link

# Set your working directory
Dir = "E:\\My Stuff\\Main School Folder\\4_Year Four\\Semester 8\\FIN 4100 - Financial Econometrics\\Assignments\\A5\\"
setwd(Dir)

# These are the default names of the files we need to download, do not change.
FileDir = list(
  RiskyAsset1 = "ENB.csv",
  RiskyAsset2 = "MSFT.csv",
  RiskFree = "F-F_Research_Data_Factors_daily.CSV",
  RealizedVolatility = "oxfordmanrealizedvolatilityindices.csv"
)


#===============================================================================
# Data Import
#===============================================================================

# Call my Excel_)Import function and list every file we need.
FileImports = Excel_Import(FileDir)
names(FileImports) = names(FileDir)


#===============================================================================
# Data Manipulation
#===============================================================================

# 1. For each data set we need to subset certain columns.
#   - RiskyAsset1: Date, Close price, and Adj Close Price
#   - RiskyAsset2: Date, Close price, and Adj Close Price
#   - RiskFree: Date and RF, and remove the copyright at the bottom
#   - RealizedVolatility: Date, SPX from Symbol Col, close price, rv10, and rv5

RiskyAsset1 = as.data.frame(FileImports[[1]][[1]])
RiskyAsset1[,2] = FileImports[[1]][[5]]
RiskyAsset1[,3] = FileImports[[1]][[6]]
names(RiskyAsset1) = c("Date", "Close.ENB", "Close.Adj.ENB")

RiskyAsset2 = as.data.frame(FileImports[[2]][[1]])
RiskyAsset2[,2] = FileImports[[2]][[5]]
RiskyAsset2[,3] = FileImports[[2]][[6]]
names(RiskyAsset2) = c("Date", "Close.MSFT", "Close.Adj.MSFT")

RiskFree = as.data.frame(FileImports[[3]][[1]])
RiskFree[,2] = as.data.frame(FileImports[[3]][[5]])
RiskFree = RiskFree[-nrow(RiskFree),1:2] # This is to delete the last row containing the copyright
names(RiskFree) = c("Date", "RF")

RealizedVolatility = as.data.frame(FileImports[[4]][[1]])
RealizedVolatility[,2] = as.data.frame(FileImports[[4]][[2]])
RealizedVolatility[,3] = as.data.frame(FileImports[[4]][[5]])
RealizedVolatility[,4] = as.data.frame(FileImports[[4]][[10]])
RealizedVolatility[,5] = as.data.frame(FileImports[[4]][[19]])
names(RealizedVolatility) = c("Date","Symbol","Close.SPX","rv10","rv5")


# 2. Now we format each data set.
#   - RiskyAsset1: Date just needs to be formatted
#   - RiskFree: Date needs to be formatted and divide RiskFree$RF by 100 to turn it into a decimal
#   - RealizedVolatility: Date format and symbol subset, I'm also going to drop
#   - the Symbol Column, I won't be needing it anymore.

RiskyAsset1[["Date"]] = as.Date(RiskyAsset1[["Date"]])

RiskyAsset2[["Date"]] = as.Date(RiskyAsset2[["Date"]])

RiskFree[["Date"]] = ymd(RiskFree[["Date"]])
RiskFree$RF = RiskFree$RF/100

RealizedVolatility[["Date"]] = as.Date(RealizedVolatility[["Date"]])
RealizedVolatility = RealizedVolatility[grepl("\\.SPX", RealizedVolatility[["Symbol"]]),1:ncol(RealizedVolatility)] # Logical mask for S&P 500 rows.
RealizedVolatility = subset(RealizedVolatility, select = -2) 


# 4. Combine 4 Data Sets onto common dates.
#   - I'm going to include as much data as I can for each data set
#   but I'll make a cut off point at the oldest date for my two stocks which is ENB/RiskyAsset1 at 1984-03-15.
#   - Then I'll just rm these datasets from the environment to clean it up.

CombinedData = merge(RiskyAsset1,RiskyAsset2,by.x="Date",by.y="Date",sort=TRUE, all = TRUE)
CombinedData = merge(CombinedData,RealizedVolatility,by.x="Date",by.y="Date",sort=TRUE, all = TRUE)
CombinedData = merge(CombinedData,RiskFree,by.x="Date",by.y="Date",sort=TRUE, all = TRUE)
CombinedData = CombinedData[CombinedData[["Date"]] >= RiskyAsset1[[1]][[1]],]

# Clean Up - won't be needing these anymore
rm(RiskyAsset1, RiskyAsset2, RiskFree, RealizedVolatility, FileDir, FileImports)

#===============================================================================
# Calculations for Assignment One
#===============================================================================

# 1. Calculate the Returns for each closing Price
#   - Using our CombinedData variable, I'll subset for a Closing price matrix
#   and calculate for returns and log returns.

CombinedData = Calculate_Returns(CombinedData)


# 2. Calculate over our Returns using some Measures and annulize it.
#   - We're going to apply the functions mean, sd, and var to each return column
#   - Then we annualize it and put it all into a matrix

A1.DailyYearlyMeasures = Calculate_Measures(CombinedData)


# 3. Calculate the Sharpe Ratio for each return against RF
# Simply take each return vector, subtract RF, and divide by standard deviation vector

A1.SharpeRatios = Calculate_SharpeRatios(A1.DailyYearlyMeasures)

#===============================================================================
# Calculations for Assignment Two
#===============================================================================

# 1. Create equal weighted portfolios between our risky and risk free asset.
# Creating an equal portfolio with each possible asset using various weights.

# Variables - This is a vector containing what weights we'd like to apply
A2.EqualPortfolioWeighting = c(0.5, 0.75, 0.9)

# Function Calls - Iterate over weighting to create returns, measures, and Sharpe ratios.
A2.EqualPortfolios            = lapply(A2.EqualPortfolioWeighting, function(x) Create_Equal_Portfolio(CombinedData, x))
A2.EqualPortfolioMeasures     = lapply(A2.EqualPortfolios, function(x) Calculate_Measures(cbind(CombinedData$RF,x))) # Include RF to include into the Sharpe ratio calculations.
A2.EqualPortfolioSharpeRatios = lapply(A2.EqualPortfolioMeasures, function(x) Calculate_SharpeRatios(x))


# 2. Create Optimal Mean Variance Portfolios
# Each portfolio is based on a single asset and our risk free rate

# Variables
# This is the different k values we will run
K = c(1,3,7)

# Function Calls - Iterate over K to create weights for our returns
# First we'll create our OMW portfolio weights
# Then we'll apply these weights to create our portfolio returns.

A2.OMVPortfolioWeights = lapply(K, function(x) Create_OMV_Portfolio(CombinedData, A1.DailyYearlyMeasures, k = x))
A2.OMVPortfolioWeightsMeasures = lapply(A2.OMVPortfolioWeights, function(x) Calculate_Measures(x)) # We can reuse an assignment one function to create our measures

A2.OMVPortfolioReturns = lapply(A2.OMVPortfolioWeights, function(x) Apply_OMV_Weights(RiskyWeight = x, Returns = CombinedData))
A2.OMVPortfolioReturns = lapply(A2.OMVPortfolioReturns, function(x) { # This is to change the colnames for each list item.
    colnames(x) = gsub("Weight.", "", colnames(x))
    return(x)
  }
)

A2.OMVPortfolioReturnsMeasures = lapply(A2.OMVPortfolioReturns, function(x) Calculate_Measures(x))

#===============================================================================
# Calculations for Assignment Three
#===============================================================================

VectorNames = c("Close.Adj.ENB"
            , "Close.Adj.MSFT"
            , "Close.SPX"
            , "Return.Adj.ENB"
            , "Return.Adj.MSFT"
            , "Return.SPX")


# Run Dickey Fuller Tests

# This Code will run our wrapper function and list all our tests: We run this three times for each type; none, drift, and trend.

A3.ADF_Tests = lapply(VectorNames
                   , function(x) Run_DF_Test(VectorName = x
                                             , lags =  c(1,7,30,60,90)
                                             , type = "none"))

names(A3.ADF_Tests) = VectorNames


A3.ADF_Tests = lapply(A3.ADF_Tests, function(x) mapply(function(y) summary(y)@teststat, y = x))

A3.ADF_Tests_TValues = do.call(rbind, A3.ADF_Tests) %>% data.frame

#===============================================================================
# Calculations for Assignment Four
#===============================================================================

# Variables
VectorNames = c("Close.Adj.ENB"
                , "Close.Adj.MSFT"
                , "Close.SPX"
                , "Return.Adj.ENB"
                , "Return.Adj.MSFT"
                , "Return.SPX"
                , "RF"
                , "rv10")


A4.Vectors = lapply(VectorNames, function(x) as.ts(CombinedData[!is.na(CombinedData[x]), x])) # Time Series Data for ARIMA and ARMA
names(A4.Vectors) = VectorNames


# Find Maximum Lags for Each Vector (Risky Asset Prices and Returns)

A4.Max.Lags = sapply(VectorNames, function(x) {
  as.numeric(floor(10 * log(length(CombinedData[!is.na(CombinedData[[x]]), x]))))
})

# Calculate ACF, PACF, Ljung-Box

A4.ACF.PACF.Ljung.1 = Run_ACF_PACF_Ljung(A4.Vectors, A4.Max.Lags) # This is using our initial risky asset prices and returns


# Setup Each ARMA and ARIMA Model

A4.Models.1 = Run_ARIMA(A4.Vectors, c(1,1,1,0,0,0,1,0))


# Find AIC BIC

AIC.BIC.1 = Run_AIC_BIC(A4.Models.1)


# According to our AIC and BIC, these are the best models for each vector

AIC.Model = mapply(function(x,y) x[[y]][[2]], x = A4.Models.1, y = AIC.BIC.1[[1]][[3]] , SIMPLIFY = FALSE)
BIC.Model = mapply(function(x,y) x[[y]][[2]], x = A4.Models.1, y = AIC.BIC.1[[2]][[3]], SIMPLIFY = FALSE)

AIC.Model = do.call(rbind, AIC.Model)
BIC.Model = do.call(rbind, BIC.Model)

A4.AIC.BIC.1 = cbind(names(A4.Models.1),AIC.BIC.1[[1]][[2]], AIC.Model, AIC.BIC.1[[2]][[2]], BIC.Model)
colnames(A4.AIC.BIC.1) = c("VectorNames", "AIC", "AIC.Model", "BIC", "BIC.Model")


# Residual Vectors from our best models

A4.AIC.Residuals = mapply(function(x,y) x[[y]][[1]][["residuals"]], x = A4.Models.1, y = AIC.BIC.1[[1]][[3]], SIMPLIFY = FALSE)
A4.BIC.Residuals = mapply(function(x,y) x[[y]][[1]][["residuals"]], x = A4.Models.1, y = AIC.BIC.1[[2]][[3]], SIMPLIFY = FALSE)


# Run ACF, PACF, and Ljung for AIC and BIC models

A4.ACF.PACF.Ljung.AIC.1 = Run_ACF_PACF_Ljung(A4.AIC.Residuals, A4.Max.Lags)
A4.ACF.PACF.Ljung.BIC.1 = Run_ACF_PACF_Ljung(A4.BIC.Residuals, A4.Max.Lags)


# Refine Our ARIMA models for MSFT and SPX prices

# Variables

A4.Models.2 = vector("list", 2) # setup empty list for each vector
A4.Models.2 = lapply(A4.Models.2, function(x) vector("list", 5*5)) # setup empty lists for each model
names(A4.Models.2) = VectorNames[2:3]

A4.Vectors = lapply(VectorNames[2:3], function(x) as.ts(CombinedData[!is.na(CombinedData[x]), x]))


# Create Models Using Seasonal Argument for ARIMA

for (i in 1:2) {
  Index = 0
  
  for (p in 1:5) {
    
    for(q in 1:5) {
      
      print(paste(i,p,q))
      
      Index = Index + 1
      model = arima(A4.Vectors[[i]], c(p,1,q), seasonal = c(1,1,0))
      order = paste(p,1,q)
      
      A4.Models.2[[i]][[Index]] = list(model,order)
      
    }
  }
}


# Tests, AIC and BIC

AIC.BIC.2 = Run_AIC_BIC(A4.Models.2)

AIC.Model = mapply(function(x,y) x[[y]][[2]], x = A4.Models.2, y = AIC.BIC.2[[1]][[3]], SIMPLIFY = FALSE)
BIC.Model = mapply(function(x,y) x[[y]][[2]], x = A4.Models.2, y = AIC.BIC.2[[2]][[3]], SIMPLIFY = FALSE)

AIC.Model = do.call(rbind, AIC.Model)
BIC.Model = do.call(rbind, BIC.Model)

A4.AIC.BIC.2 = cbind(VectorNames[2:3],AIC.BIC.2[[1]][[2]], AIC.Model, AIC.BIC.2[[2]][[2]], BIC.Model)
colnames(A4.AIC.BIC.2) = c("VectorNames", "AIC", "AIC.Model", "BIC", "BIC.Model")

A4.AIC.Seasonal.Residuals = mapply(function(x,y) x[[y]][[1]][["residuals"]], x = A4.Models.2, y = AIC.BIC.2[[1]][[3]], SIMPLIFY = FALSE)
A4.BIC.Seasonal.Residuals = mapply(function(x,y) x[[y]][[1]][["residuals"]], x = A4.Models.2, y = AIC.BIC.2[[2]][[3]], SIMPLIFY = FALSE)

A4.ACF.PACF.Ljung.AIC.2 = Run_ACF_PACF_Ljung(A4.AIC.Seasonal.Residuals, A4.Max.Lags[2:3])
A4.ACF.PACF.Ljung.BIC.2 = Run_ACF_PACF_Ljung(A4.BIC.Seasonal.Residuals, A4.Max.Lags[2:3])

# Some Cleanup

rm(AIC.Model, BIC.Model, p, q, i, Index, order)


#===============================================================================
# Calculations for Assignment Five
#===============================================================================

# We need to take our residuals from our earlier chosen models
#   - Our AIC models preformed better so we'll just be reusing those.
#   - We'll also take our seasonal AIC model residuals

A5.Residuals = A4.AIC.Residuals
# A5.Residuals[2:3] = A4.AIC.Seasonal.Residuals

# Create our Squared Residuals

A5.Residuals.Squared = lapply(A5.Residuals, function(x) x**2)

# Convert from time series to data frames, for plotting purposes.

A5.Residuals.Squared.DF = mapply(function(x,y) {
  
  df = x %>% as.numeric()
  df = df %>% data.frame()
  
  date = CombinedData %>% select(y, "Date") %>%  na.omit()
  df$date = date[,2]
  
  colnames(df) = c("residual", "date")
  
  return(df)
  
}
, x = A5.Residuals.Squared
, y = VectorNames
, SIMPLIFY = FALSE

)

# ACF PACF and Ljung for my Residuals Squared
A5.ACF.PACF.Ljung.1 = Run_ACF_PACF_Ljung(A5.Residuals.Squared, A4.Max.Lags)

# Optimal ARIMA Model Specification
#   - I need to grab my optimal orders from prior tests (A4.AIC.BIC.1 and 2)

A5.Order = lapply(A4.AIC.BIC.1[,3], function(x) {
  c(substr(x,1,1)
    , substr(x,5,5)) %>% as.numeric()
  
})

# A5.Order.temp = lapply(A4.AIC.BIC.2[,3], function(x) {
#   c(substr(x,1,1)
#     , substr(x,5,5)) %>% as.numeric()
#   
# })
# 
# A5.Order[2:3] = A5.Order.temp
# rm(A5.Order.temp)

A5.Optimal.ARIMA = lapply(A5.Order, function(x) arfimaspec(mean.model = list(armaOrder = as.vector(x), include.mean = TRUE)))
A5.Optimal.Fit = mapply(function(x,y) arfimafit(x,y), x = A5.Optimal.ARIMA, y = A5.Residuals.Squared)

# ARCH and GARCH
#   - Setup xts data
#   - Run loop for various p and q combinations for GARCH model

# A5.Vectors = lapply(VectorNames, function(x) data.frame(x = CombinedData[!is.na(CombinedData[x]), x], Date = CombinedData[!is.na(CombinedData[x]), "Date"])) # Time Series Data for ARIMA and ARMA
# names(A5.Vectors) = VectorNames

A5.XTS = lapply(A5.Residuals.Squared.DF, function(x) xts(x[,1], order.by = x[,2]))

A5.GARCH.Models = vector("list", length(A5.Residuals.Squared.DF)) # setup empty list for each vector
A5.GARCH.Models = lapply(A5.GARCH.Models, function(x) vector("list", 5*5)) # setup empty lists for each model

for (i in 1:length(A5.Residuals.Squared.DF)) {
  Index = 1
  print(paste("Starting...", names(A5.Residuals.Squared.DF)[Index]))
  
  for (p in 1:5) {
    
    for(q in 1:5) {
      
      print(paste(i,p,q))
      
      model = ugarchspec(variance.model = list(model = "sGARCH", garchOrder = c(p,q))
                         , mean.model = list(aeamaOrder = A5.Order[[i]], include.mean = TRUE))
      
      print("Here?")
      A5.GARCH.Models[[i]][[Index]] = list(ugarchfit(model, unlist(A5.XTS[[i]]), solver = "hybrid"))
      A5.GARCH.Models[[i]][[Index]][[2]] = c(p,q)
      
      Index = Index + 1
      
    }
  }
  
}


# Find AIC, BIC, and best models.
A5.GARCH.Models.backup = A5.GARCH.Models
A5.GARCH.Models = A5.GARCH.Models[1:6]


AIC.BIC.3 = Run_AIC_BIC_2(A5.GARCH.Models)

AIC.Model = mapply(function(x,y) x[[y]][[2]], x = A5.GARCH.Models, y = AIC.BIC.3[[1]][[3]], SIMPLIFY = FALSE)
BIC.Model = mapply(function(x,y) x[[y]][[2]], x = A5.GARCH.Models, y = AIC.BIC.3[[2]][[3]], SIMPLIFY = FALSE)

AIC.Model = do.call(rbind, AIC.Model)
BIC.Model = do.call(rbind, BIC.Model)

A5.AIC.BIC.1 = cbind(VectorNames[1:6], AIC.BIC.3[[1]][[2]], AIC.Model, AIC.BIC.3[[2]][[2]], BIC.Model)
colnames(A5.AIC.BIC.1) = c("VectorNames", "AIC", "p", "q", "BIC", "p", "q")

A5.AIC.GARCH.Residuals = mapply(function(x,y) residuals(x[[y]][[1]], standardize = TRUE)**2, x = A5.GARCH.Models, y = AIC.BIC.3[[1]][[3]], SIMPLIFY = FALSE)
#A5.BIC.GARCH.Residuals = mapply(function(x,y) residuals(x[[y]][[1]], standardize = TRUE)**2, x = A5.GARCH.Models, y = AIC.BIC.3[[2]][[3]], SIMPLIFY = FALSE)

A5.ACF.PACF.Ljung.AIC.GARCH = Run_ACF_PACF_Ljung(A5.AIC.GARCH.Residuals, A4.Max.Lags[1:6])
#A5.ACF.PACF.Ljung.BIC.GARCH = Run_ACF_PACF_Ljung(A5.BIC.GARCH.Residuals, A4.Max.Lags[1:6])

# Coefficients and Standard Errors

A5.GARCH.COEF = mapply(function(x,y) coef(x[[y]][[1]]), x = A5.GARCH.Models, y = AIC.BIC.3[[1]][[3]], SIMPLIFY = FALSE)
A5.GARCH.VCOV = mapply(function(x,y) vcov(x[[y]][[1]]), x = A5.GARCH.Models, y = AIC.BIC.3[[1]][[3]], SIMPLIFY = FALSE)
A5.GARCH.SE   = lapply(A5.GARCH.VCOV, function(x) sqrt(diag(x)))

A5.GARCH.COEF = data.frame(do.call(rbind, A5.GARCH.COEF))
A5.GARCH.SE = data.frame(do.call(rbind, A5.GARCH.SE))

GARCH.Data = list(A5.GARCH.COEF, A5.GARCH.SE)
names(GARCH.Data) = c("COEF", "SE")

Excel_Export(GARCH.Data, FileName = "coefVcovSe.xlsx")

# GARCH Forecast

A5.GARCH.Forecast = mapply(function(x,y,z) {
  optimal = x[[y]][[1]]
  spec = getspec(optimal)
  setfixed(spec) = as.list(coef(optimal))
  forecast = ugarchforecast(spec, data = z, n.ahead = 1, n.roll = 2000, out.sample = 2000)
  print("Here")
  condVarForecast = sigma(optimal)
  
  return(list(spec,forecast,condVarForecast))
  
}
  , x = A5.GARCH.Models
  , y = AIC.BIC.3[[1]][[3]], SIMPLIFY = FALSE
  , z = A5.XTS[1:6]
)

A5.GARCH.Forecast[[6]][[2]] %>% plot


# Portfolio Allocation

mrisky = CombinedData[["Return.Adj.ENB"]] %>% na.omit() %>% mean()
mriskless = CombinedData[["RF"]] %>% na.omit() %>% mean()
k = 1
vrisky = CombinedData[["Return.Adj.ENB"]] %>% na.omit() %>% var()

optimalweightriskless = (mrisky - mriskless) / (k*vrisky)


A5.Return.Vectors = lapply(VectorNames[4:6], function(x) as.ts(CombinedData[!is.na(CombinedData[x]), x]))

A5.Porfolio.Allocation = mapply(function(x,y) {
  # Risky and Riskless Assets
  mean_risky = x %>% mean()
  mean_riskless = CombinedData[["RF"]] %>% na.omit() %>% mean()
  
  # Risk Aversions
  k = c(1,5,7)
  
  # Variances
  variance_risky = x %>% var()
  max_volitility = y[[3]] %>% max()
  min_volitility = y[[3]] %>% min()
  
  Optimal_Weights_Var = (mean_risky - mean_riskless) / (k*variance_risky)
  Optimal_Weights_Max = (mean_risky - mean_riskless) / (k*max_volitility)
  Optimal_Weights_Min = (mean_risky - mean_riskless) / (k*min_volitility)
  
  return(list(Optimal_Weights_Var, Optimal_Weights_Max, Optimal_Weights_Min))
  
}
, x = A5.Return.Vectors
, y = A5.GARCH.Forecast[4:6]
, SIMPLIFY = FALSE
)


A5.Porfolio.Allocation.Matrix = lapply(A5.Porfolio.Allocation, function(x) do.call(rbind, x))
A5.Porfolio.Allocation.Matrix = do.call(rbind, A5.Porfolio.Allocation.Matrix)
A5.Porfolio.Allocation.Matrix = data.frame(A5.Porfolio.Allocation.Matrix)

write.csv(A5.Porfolio.Allocation.Matrix, "port allo matx.csv")


#===============================================================================
# Plots for Assignment One
#===============================================================================

# 1. Setting Up Long Data
#   - For 1 and 2, I'm setting up long data to capture each Return or Close price
#   as a separate class for my gather() function.

Colnames1 = colnames(CombinedData[,grepl("Return|RF", colnames(CombinedData))])
Colnames2 = colnames(CombinedData[,grepl("Close", colnames(CombinedData))])

PlotData = gather(CombinedData, Return.Asset, Return, Colnames1)
PlotData = PlotData[order(PlotData$Return.Asset),]

PlotData2 = gather(CombinedData, Close.Asset, Close, Colnames2)
PlotData2 = PlotData2[order(PlotData2$Close.Asset),]


# 2. Plots for Wider Data
#   - Returns: Split into regular returns and log returns.
#   - Close Prices: Graph one normally and use log on the other.

LogIndex = grepl("Log", PlotData$Return.Asset)
RFIndex = grepl("RF", PlotData$Return.Asset)

ggplot(data = PlotData[which(!LogIndex == TRUE | RFIndex == TRUE),], mapping = aes(x = Date, y = Return, color = Return.Asset)) +
  geom_point(size = 0.5) +
  geom_line(size = 0.5) +
  ggtitle("All Returns")
  ggsave(filename = "Plot - All Returns.png")

ggplot(data = PlotData[which(LogIndex == TRUE | RFIndex == TRUE),], mapping = aes(x = Date, y = Return, color = Return.Asset)) +
  geom_point(size = 0.5) +
  geom_line(size = 0.5) +
  ggtitle("All Log Returns")
  ggsave(filename = "Plot - All Log Returns.png")

ggplot(data = PlotData2, mapping = aes(x = Date, y = Close, color = Close.Asset)) +
  geom_point(size = 0.5) +
  geom_line(size = 0.5) +
  ggtitle("All Close Prices")
  ggsave(filename = "Plot - All Closes.png")

ggplot(data = PlotData2, mapping = aes(x = Date, y = log(Close), color = Close.Asset)) +
  geom_point(size = 0.5) +
  geom_line(size = 0.5) +
  ggtitle("All Log Close Prices")
  ggsave(filename = "Plot - All Log Closes.png")


# 3. Plots for Each column from our CombinedData variable and export to our working directory.
  
for(i in 1:ncol(CombinedData)) {
  
  if(i == ncol(CombinedData)) {
    i = 1
    next()
    
  } else {
    
    PlotName = paste0("Plot - ", colnames(CombinedData)[i+1], ".png")
    yaxis = {
      if(grepl("Close", colnames(CombinedData)[i+1])) {
        "Close"
        
      } else if (grepl("Return|RF", colnames(CombinedData)[i+1])) {
        "Return"
      }
    }
    
    print(ggplot(data = CombinedData, mapping = aes(x = Date, y = CombinedData[,(i+1)])) +
            geom_point(alpha = 0.05) +
            geom_line()) +
      ylab(label = yaxis) +
      ggtitle(paste0("Plot - ", colnames(CombinedData)[i+1]))
    ggsave(file=PlotName)
    
  }
}


#===============================================================================
# Plots for Assignment Two
#===============================================================================
  
# 1. Plot Portfolio Returns and Weights

# Optimal Mean Variance Returns

PlotDataOMV = lapply(OMVPortfolioReturns, function(x) GroupByKey(cbind(CombinedData$Date,x),"Return"))
PlotDataOMV = lapply(PlotDataOMV, function(x) { # Clean for just log.adj and log.spx
  x = x[grepl("Log.Adj|Log.SPX", x[,2]),]
  return(x)
})
 

for (i in seq_along(PlotDataOMV)) {
  
  ggplot(data = PlotDataOMV[[i]], mapping = aes(x = Date, y = Return, color = Return.Asset)) +
    geom_point(size = 0.5) +
    geom_line(size = 0.5) +
    ggtitle(paste0("All OMV Returns ", "K = ", K[i]))
    
  ggsave(filename = paste0("Plot - All OMV Returns ", "K = ", K[i], ".png"))
  
}

# Optimal Mean Variance Weights

PlotDataOMVWeight = lapply(A2.OMVPortfolioWeights, function(x) GroupByKey(cbind(CombinedData$Date,x %>% as.data.frame()), "Weight"))
PlotDataOMVWeight = lapply(PlotDataOMVWeight, function(x) { # Clean for just log.adj and log.spx
  x = x[grepl("Log.Adj|Log.SPX", x[,2]),]
  return(x)
})


for (i in seq_along(PlotDataOMVWeight)) {
  
  ggplot(data = PlotDataOMVWeight[[i]], mapping = aes(x = Date, y = Weight, color = Weight.Asset)) +
    geom_point(size = 0.5) +
    geom_line(size = 0.5) +
    ggtitle(paste0("All OMV Weights ", "K = ", K[i]))
  
  ggsave(filename = paste0("Plot - All OMV Weights ", "K = ", K[i], ".png"))
  
}

# Equal Portfolio Returns

PlotDataEPReturns = lapply(A2.EqualPortfolios, function(x) GroupByKey(x,"Return"))
PlotDataEPReturns = lapply(PlotDataEPReturns, function(x) { # Clean for just log.adj and log.spx
  x = x[grepl("Log.Adj|Log.SPX", x[,2]),]
  return(x)
})


for (i in seq_along(A2.EqualPortfolios)) {
  
  ggplot(data = PlotDataEPReturns[[i]], mapping = aes(x = Date, y = Weight, color = Weight.Asset)) +
    geom_point(size = 0.5) +
    geom_line(size = 0.5) +
    ggtitle(paste0("All EP Returns ", "Weight = ", A2.EqualPortfolioWeighting[i]))
  
  ggsave(filename = paste0("Plot - All EP Returns ", "Weight = ", A2.EqualPortfolioWeighting[i], ".png"))
  
}


# New Alternative for Plotting

mapply(function(l, m) 
    PlotbyList(
      PlotData = l,
      x = "Date",
      y = "Weight",
      color = "Weight.Asset",
      title ="All OMW Weights, K = ",
      index = m),
  l = PlotDataOMVWeight,
  m = K,
  SIMPLIFY = FALSE
)

# If I want to edit the data going in I can use the below code for the data argument in ggplot
# PlotDataOMVWeight[[i]][grepl("ENB$", PlotDataOMVWeight[[i]][,"Weight.Asset"]),]


#===============================================================================
# Plots for Assignment Three
#===============================================================================

# Price Plots

ggplot(CombinedData, aes(x = Date, y = Close.Adj.ENB)) +
  geom_point(size = 0.5) + geom_line() +
  ggtitle("Close.Adj.ENB Price")

ggplot(CombinedData, aes(x = Date, y = Close.Adj.MSFT)) +
  geom_point(size = 0.5) + geom_line() +
  ggtitle("Close.Adj.MSFT Price")

ggplot(CombinedData, aes(x = Date, y = Close.SPX)) +
  geom_point(size = 0.5) + geom_line() +
  ggtitle("Close.SPX Price")

# Return Plots
  
ggplot(CombinedData, aes(x = Date, y = Return.Adj.ENB)) +
  geom_point(size = 0.5) + geom_line() +
  ggtitle("Return.Adj.ENB Price")

ggplot(CombinedData, aes(x = Date, y = Return.Adj.MSFT)) +
  geom_point(size = 0.5) + geom_line() +
  ggtitle("Return.Adj.MSFT Price")

ggplot(CombinedData, aes(x = Date, y = Return.SPX)) +
  geom_point(size = 0.5) + geom_line() +
  ggtitle("Return.SPX Price")


#===============================================================================
# Plots for Assignment Four
#===============================================================================

# Plots for ACF and PACF with and without xlim = 10

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
    return({
      jpeg(paste0("ACF.", y,".jpg"), width = 250, height = 250)
      plot(x, main = paste0("ACF ", y))
      dev.off()
    })
    
  }
  , SIMPLIFY = FALSE
  , x = A4.ACF.PACF.Ljung.1[[1]]
  , y = names(A4.ACF.PACF.Ljung.1[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
    return({
      jpeg(paste0("PACF.", y,".jpg"), width = 250, height = 250)
      plot(x, main = paste0("PACF ", y))
      dev.off()
    })
    
  }
  , SIMPLIFY = FALSE
  , x = A4.ACF.PACF.Ljung.1[[2]]
  , y = names( A4.ACF.PACF.Ljung.1[[2]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("ACF with ylim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("ACF ", y), ylim = c(-0.15, 0.15))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x =  A4.ACF.PACF.Ljung.1[[1]]
, y = names(A4.ACF.PACF.Ljung.1[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("PACF with xlim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("PACF ", y), xlim = c(0, 10))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.1[[2]]
, y = names(A4.ACF.PACF.Ljung.1[[2]])
)


# Plots for ACF and PACF with and without xlim = 10 for our Optimal Models under AIC

# AIC

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC ACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("ACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.AIC.1[[1]]
, y = names(A4.ACF.PACF.Ljung.AIC.1[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC PACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("PACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.AIC.1[[2]]
, y = names(A4.ACF.PACF.Ljung.AIC.1[[2]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC ACF with ylim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("ACF ", y), ylim = c(-0.15, 0.15))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.AIC.1[[1]]
, y = names(A4.ACF.PACF.Ljung.AIC.1[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC PACF with xlim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("PACF ", y), xlim = c(0,10))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.AIC.1[[2]]
, y = names(A4.ACF.PACF.Ljung.AIC.1[[2]])
)

# BIC


mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("BIC ACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("ACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.BIC.1[[1]]
, y = names(A4.ACF.PACF.Ljung.BIC.1[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("BIC PACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("PACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.BIC.1[[2]]
, y = namers(A4.ACF.PACF.Ljung.BIC.1[[2]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("BIC ACF with ylim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("ACF ", y), ylim = c(-0.15, 0.15))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.BIC.1[[1]]
, y = names(A4.ACF.PACF.Ljung.BIC.1[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("BIC PACF with xlim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("PACF ", y), xlim = c(0, 10))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.BIC.1[[2]]
, y = names(A4.ACF.PACF.Ljung.BIC.1[[2]])
)

# Plots for AIC BIC for New Seasonal Model

# AIC


mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC ACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("ACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.AIC.2[[1]]
, y = names(A4.ACF.PACF.Ljung.AIC.2[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC PACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("PACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.AIC.2[[2]]
, y = names(A4.ACF.PACF.Ljung.AIC.2[[2]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC ACF with ylim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("ACF ", y), ylim = c(-0.15, 0.15))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.AIC.2[[1]]
, y = names(A4.ACF.PACF.Ljung.AIC.2[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC PACF with xlim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("PACF ", y), xlim = c(0,10))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.AIC.2[[2]]
, y = names(A4.ACF.PACF.Ljung.AIC.2[[2]])
)


# BIC


mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("BIC ACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("ACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.BIC.2[[1]]
, y = names(A4.ACF.PACF.Ljung.BIC.2[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("BIC PACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("PACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.BIC.2[[2]]
, y = namers(A4.ACF.PACF.Ljung.BIC.2[[2]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("BIC ACF with ylim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("ACF ", y), ylim = c(-0.15, 0.15))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.BIC.2[[1]]
, y = names(A4.ACF.PACF.Ljung.BIC.2[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("BIC PACF with xlim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("PACF ", y), xlim = c(0, 10))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A4.ACF.PACF.Ljung.BIC.2[[2]]
, y = names(A4.ACF.PACF.Ljung.BIC.2[[2]])
)

#===============================================================================
# Plots for Assignment Five
#===============================================================================

# Plot my Residuals Squared with Dates

mapply(function(x,y) PlotResidualsSquared(x,y), x = A5.Residuals.Squared.DF, y = VectorNames)


# ACF and PACF plots for Residual Squared data

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("ACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("ACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A5.ACF.PACF.Ljung.1[[1]]
, y = names(A5.ACF.PACF.Ljung.1[[1]])
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("PACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("PACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A5.ACF.PACF.Ljung.1[[2]]
, y = names(A5.ACF.PACF.Ljung.1[[2]])
)

# Plot GARCH Standardized Residuals

# AIC

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC ACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("ACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A5.ACF.PACF.Ljung.AIC.GARCH[[1]]
, y = VectorNames[1:6]
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC PACF.", y,".jpg"), width = 250, height = 250)
    plot(x, main = paste0("PACF ", y))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A5.ACF.PACF.Ljung.AIC.GARCH[[2]]
, y = VectorNames[1:6]
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC ACF with ylim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("ACF ", y), ylim = c(-0.10, 0.10))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A5.ACF.PACF.Ljung.AIC.GARCH[[1]]
, y = VectorNames
)

mapply(function(x,y) {
  # Function to unlist, plot, and export graphs
  return({
    jpeg(paste0("AIC PACF with xlim ", y,".jpg"), width = 250, height = 250)
    plot(x[2:91], main = paste0("PACF ", y), xlim = c(0,10))
    dev.off()
  })
  
}
, SIMPLIFY = FALSE
, x = A5.ACF.PACF.Ljung.AIC.GARCH[[2]]
, y = VectorNames
)


# BIC

# mapply(function(x,y) {
#   # Function to unlist, plot, and export graphs
#   return({
#     jpeg(paste0("BIC ACF.", y,".jpg"), width = 250, height = 250)
#     plot(x, main = paste0("ACF ", y))
#     dev.off()
#   })
#   
# }
# , SIMPLIFY = FALSE
# , x = A5.ACF.PACF.Ljung.BIC.GARCH[[1]]
# , y = VectorNames
# )
# 
# mapply(function(x,y) {
#   # Function to unlist, plot, and export graphs
#   return({
#     jpeg(paste0("BIC PACF.", y,".jpg"), width = 250, height = 250)
#     plot(x, main = paste0("PACF ", y))
#     dev.off()
#   })
#   
# }
# , SIMPLIFY = FALSE
# , x = A5.ACF.PACF.Ljung.BIC.GARCH[[2]]
# , y = VectorNames
# )
# 
# mapply(function(x,y) {
#   # Function to unlist, plot, and export graphs
#   return({
#     jpeg(paste0("BIC ACF with ylim ", y,".jpg"), width = 250, height = 250)
#     plot(x[2:91], main = paste0("ACF ", y), ylim = c(-0.15, 0.15))
#     dev.off()
#   })
#   
# }
# , SIMPLIFY = FALSE
# , x = A5.ACF.PACF.Ljung.BIC.GARCH[[1]]
# , y = VectorNames
# )
# 
# mapply(function(x,y) {
#   # Function to unlist, plot, and export graphs
#   return({
#     jpeg(paste0("BIC PACF with xlim ", y,".jpg"), width = 250, height = 250)
#     plot(x[2:91], main = paste0("PACF ", y), xlim = c(0, 10))
#     dev.off()
#   })
#   
# }
# , SIMPLIFY = FALSE
# , x = A5.ACF.PACF.Ljung.BIC.GARCH[[2]]
# , y = VectorNames
# )


#===============================================================================
# Excel Export
#===============================================================================

# Assignment One Exports

FileExport = list(CombinedData
                  , DailyYearlyMeasures
                  , SharpeRatios
                  )

names(FileExport) = c("CombinedData"
                      , "DailyYearlyMeasures"
                      , "SharpeRatios"
                      )

Excel_Export(FileExport, FileName = "Assignment 1 Data.xlsx", Dir)


# Assignment Two Exports

#   1. Optimal Mean Variance Portfolio Data

FileExport = c(OMVPortfolioReturns,A2.OMVPortfolioReturnsMeasures, A2.OMVPortfolioWeights, A2.OMVPortfolioWeightsMeasures)

names(FileExport) = c(
  paste0(rep("OMV ", 3), "Return ", seq(1,3,1)),
  paste0(rep("OMV ", 3), "ReturnMeasures ", seq(1,3,1)),
  paste0(rep("OMV ", 3), "Weights ", seq(1,3,1)),
  paste0(rep("OMV ", 3), "WeightsMeasures ", seq(1,3,1))
)

Excel_Export(FileExport, FileName = "OMV Data.xlsx")


#   2. Equal Portfolio Data

FileExport = c(A2.EqualPortfolios, A2.EqualPortfolioMeasures, A2.EqualPortfolioSharpeRatios)

names(FileExport) = c(
  paste0(rep("EP ", 3), "Return ", seq(1,3,1)),
  paste0(rep("EP ", 3), "ReturnMeasures ", seq(1,3,1)),
  paste0(rep("EP ", 3), "SharpeRatios ", seq(1,3,1))
)

Excel_Export(FileExport, FileName = "EP Data.xlsx")


# Assignment Three Exports

write.xlsx(A3.ADF_Tests_TValues, file = "ADF Test Values.xlsx")

# Assignment Four Exports

write.csv(data.frame(A4.Max.Lags), "vec_lag.csv") # table for max lags
write.csv(unlist(A4.Ljung.pvalues), "Ljung_pvalue.csv") # table for max lags
write.csv(A4.AIC.BIC.Test, "AIC_BIC_Test.csv")
write.csv(A4.ARIMA.AIC.Ljung.pvalues, "ARIMA_AIC_LJUNG.csv")
write.csv(A4.ARIMA.BIC.Ljung.pvalues, "ARIMA_BIC_LJUNG.csv")
write.csv(AIC.MIN.Model, "AIC.MIN.MODEL.csv")
write.csv(A4.Best.Ljung.pvalues, "Ljung.best.csv")

# Assignment Five Exports

write.csv(A5.ACF.PACF.Ljung.1[[3]], "a5 ljung test for sqr res.csv")
write.csv(A5.AIC.BIC.1, "a5 aic and bic.csv")
write.csv(A5.ACF.PACF.Ljung.AIC.GARCH[[3]], "a5 garch ljung.csv")
#===============================================================================
# End of Script
#===============================================================================