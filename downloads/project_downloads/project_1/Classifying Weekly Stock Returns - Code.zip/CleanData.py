# -*- coding: utf-8 -*-
"""
Created on Tue Apr  4 21:12:01 2023

@author: Paul
"""

# =============================================================================
# Clean Data
# =============================================================================


# Packages --------------------------------------------------------------------

import pandas as pd
import numpy as np

import os

#------------------------------------------------------------------------------


# Load Our Data ---------------------------------------------------------------

# WD
path = "E:\\My Stuff\\Main School Folder\\5_Year Five - Masters\\Semester 10 (OneDrive)\\FIN 6200 - Artificial Intelligence in Finace - Financial Econometrics\\Final Project\\Datasets"
os.chdir(path)

# Silicon Valley Bank
SVB = pd.read_csv("SIVBQ.csv")

# US T-Bills
RFR = pd.read_csv("FRB_H15.csv", skiprows=5)

# MBS USD Value (Only Major Banks)
MBS = pd.read_csv("TMBLCBW027SBOG.csv")

#------------------------------------------------------------------------------


# Clean Data ------------------------------------------------------------------

# SVB
SVB["Date"] = pd.to_datetime(SVB["Date"]) # Set Date format
SVB = SVB.set_index("Date") # Set index
SVB.index = SVB.index.date # Set index to date
SVB = SVB.fillna(method='ffill') # forward fill

# US T-Bills
RFR = RFR.iloc[:,0:3] # Keep first three columns (4-week and 1-year is missing too much data)
RFR["Time Period"] = pd.to_datetime(RFR["Time Period"])
RFR = RFR.set_index("Time Period") # Set Index
RFR.index = RFR.index.date
RFR = RFR.dropna() # Nothing drops, so no NAs.
RFR = RFR.replace({"ND": np.nan}) # Replace string ND with nan
RFR = RFR.fillna(method='ffill') # forward fill
RFR = RFR.iloc[1:,::] # First value had NA so I dropped it

# MBS
MBS["DATE"] = pd.to_datetime(MBS["DATE"]) # Set Date format
MBS.columns
MBS = MBS.set_index("DATE") # Set index
MBS = MBS.resample("B").ffill() # forward fill
MBS.index = MBS.index.date # Set index to date
#------------------------------------------------------------------------------


# Combine Datasets ------------------------------------------------------------

df = pd.merge(SVB, RFR, left_index=True, right_index=True, how="outer") # Outer merge
df = pd.merge(df, MBS, left_index=True, right_index=True, how="outer") # Outer merge

df.iloc[:,-1] = (df.iloc[:,-1]).fillna(method='ffill') # Forward fill
df = df.dropna(subset=['TMBLCBW027SBOG']) # Drop any na's found in MBS
df = df.fillna(method='ffill') # Forward fill na values

df = df.iloc[3:,:] # Trim first couple of rows to remove NAs
df = df.iloc[:-1,:] # Remove last report to fit data to full business weeks.
#------------------------------------------------------------------------------


# Check if Weeks are full -----------------------------------------------------
df.index = pd.to_datetime(df.index)

# resample the data at a weekly frequency and count the number of observations per week
weekly_counts = df.resample('W').count()

# calculate the expected number of observations per week
expected_counts = 5  # since there are 5 business days in a week

# find the index values of the weeks where the count of observations is less than the expected count
missing_weeks = weekly_counts[weekly_counts < expected_counts].dropna().index

# print the index values of the missing weeks
if len(missing_weeks) > 0:
    print(f'The following weeks are missing a business day: {missing_weeks}')
else:
    print('All weeks have all business days')
#------------------------------------------------------------------------------




# Export ----------------------------------------------------------------------

# Move the index to a column named "Date"
df.reset_index(inplace=True)
df.rename(columns={'index': 'Date'}, inplace=True)

df.to_csv("projectdata.csv", index=False)

#------------------------------------------------------------------------------