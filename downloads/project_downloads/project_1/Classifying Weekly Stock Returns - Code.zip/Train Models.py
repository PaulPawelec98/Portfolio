# -*- coding: utf-8 -*-
"""
Created on Mon Apr 17 12:40:36 2023

@author: Paul
"""

# =============================================================================
# Load Packages
# =============================================================================

# Data Related
import numpy as np
import pandas as pd

# To Change Directories
import os

# Plotting
import matplotlib.pyplot as plt
import math # For deciding the grid size
import seaborn as sns


# Creating and Formating Train and Test Sets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Models and Implementation
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor
import xgboost as xgb
from sklearn.tree import DecisionTreeRegressor
from sklearn import tree
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.ensemble import VotingClassifier
from sklearn.pipeline import make_pipeline, Pipeline
import random

# Accuracy
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.metrics import classification_report


# =============================================================================
# Set Seed
# =============================================================================

# Setting the seed to 1
np.random.seed(1)

# =============================================================================
# Pull Data
# =============================================================================
# Data is cleaned in prior script called "CleanData.py".
# - This just combines all our datasets into one uniform DataFrame
#  Contains daily stock data for SVB, Domestic Bank Mortgage Securities, and
#  3-month and 6-month rates

path = "C:\\Users\Paul\\OneDrive - University of Guelph\\Semester Folders\\Semester 10\\FIN 6200 - Artificial Intelligence in Finace - Financial Econometrics\\Final Project\\Datasets"
os.chdir(path)
del(path)

df = pd.read_csv("projectdata.csv")
df = df.rename(columns = {"RIFSGFSM03_N.B":"M03","RIFSGFSM06_N.B":"M06","TMBLCBW027SBOG":"MBS"})


# =============================================================================
# Weekly Returns, Weekly Data Format, Look at Data
# =============================================================================

# Format Date to DateTime and set to index
df['Date'] = pd.to_datetime(df['Date'])
df.set_index('Date', inplace=True)

# Calculate Weekly Return
weekly_returns = df.groupby(pd.Grouper(freq='5B'))['Adj Close'].last().pct_change()


# =============================================================================
# Categotirize Returns
# =============================================================================

def categorize_return(weekly_return):
    if weekly_return >= 0:
        return 1
    elif weekly_return < 0:
        return 0

weekly_returns_cat = pd.DataFrame(weekly_returns.apply(lambda x: categorize_return(x)))
weekly_returns_cat.columns = ["Return"]


# =============================================================================
# Additional Data Prep
# =============================================================================
# Need to aggregate weekly data and setup a new dataframe

# Create Weekly 1,2,3,4 differences for each column ---------------------------
df2 = pd.DataFrame()

for i in range(0, len(df), 5):
    
    data = df.iloc[i:i+5]
    data_lag = data.shift(-1)
    
    data = data.drop(data.index[4])
    data_lag = data_lag.drop(data_lag.index[4])
    
    diff = data_lag - data
    
    diff2 = np.concatenate((diff.iloc[:,0].values,
                    diff.iloc[:,1].values,
                    diff.iloc[:,2].values,
                    diff.iloc[:,3].values,
                    diff.iloc[:,4].values,
                    diff.iloc[:,5].values,
                    diff.iloc[:,6].values,
                    diff.iloc[:,7].values,
                    diff.iloc[:,8].values,
                    ))
    
    diff2 = pd.DataFrame(diff2).T
        
    df2 = pd.concat([df2,diff2])
    
del(i, data, data_lag, diff, diff2)

# original column names
cols = df.columns

# number of lagged columns to generate
n_lags = 4

# generate new column names
new_cols = []
for col in cols:
    for i in range(1, n_lags+1):
        new_col = f"{col}-{i}"
        new_cols.append(new_col)

# print new column names
df2.columns = new_cols

del (i, col, cols, n_lags, new_col)
#------------------------------------------------------------------------------


# Add Weekly Returns to DF2 ---------------------------------------------------
df2 = df2[:-1]
weekly_returns_cat = weekly_returns_cat[1:]
df2['Return'] = weekly_returns_cat.values
#------------------------------------------------------------------------------


# Drop Some Columns -----------------------------------------------------------
# The weekly MBS data won't work for doing this kind of differencing.
# So we just drop a couple of them and keep one of the columns that captures
# the weekly change

df2 = df2.drop([new_cols[-1],new_cols[-2],new_cols[-4]], axis=1)
df2 = df2.rename(columns = {"MBS-2":"MBS-1"})
#------------------------------------------------------------------------------


# =============================================================================
# Descriptive Statistics
# =============================================================================

# Summary statistics
summary1 = df.describe()
summary2 = df2.describe()

# Correlation matrix heatmap
corr_matrix = df.corr()
sns.heatmap(corr_matrix, cmap='coolwarm')

corr_matrix2 = df2.corr()
sns.heatmap(corr_matrix2, cmap='coolwarm', annot=False, linewidths=0.5)


# =============================================================================
# Sampling
# =============================================================================

# Drop Observations at random
# df2 = df2.sample(frac=0.6, random_state=42)

# # Trim Observations down
years_2 = 52*2
df2 = df2.iloc[-years_2:,:]

# =============================================================================
# Create Train and Test Sets
# =============================================================================

print("Starting: Create Train and Test Sets")

# Split into Training and Test Sets -------------------------------------------
X = df2.drop('Return', axis=1)
y = df2['Return']

# Split in Order
n_test = int(0.50 * len(X))
split_index = len(X) - n_test
X_train, X_test = X[:split_index], X[split_index:]
y_train, y_test = y[:split_index], y[split_index:]


# Split Randomly
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.35, random_state=42)

#------------------------------------------------------------------------------


# Scale Data ------------------------------------------------------------------

sc = StandardScaler()
X_train_scaled = sc.fit_transform(X_train)
X_test_scaled  = sc.transform(X_test)

#------------------------------------------------------------------------------

print("Finished: Create Train and Test Sets")

# =============================================================================
# Create and Fit Models
# =============================================================================

print("Starting: Create and Fit Models")

# Store Models ----------------------------------------------------------------

Fitted_Models = {}

#------------------------------------------------------------------------------


# Notes -----------------------------------------------------------------------

# CV Folds
# - Using a higher number of these dosen't seem to improve my results.

#------------------------------------------------------------------------------


# Parameters ------------------------------------------------------------------

n_cv = 3

# C_grid = [10**10,10**-4, 10**-3,10**-2,10**-1,10**0,10**1,10**2,10**3, 10**4]
C_grid = [0.5] # Gives the same results as 10**4
# C_grid = [10**-4]
param_grid = {'C': C_grid}

#------------------------------------------------------------------------------


# Logistic Regression ---------------------------------------------------------

print("Logistic Regression")

model = GridSearchCV(LogisticRegression(penalty=None), param_grid=param_grid,cv = n_cv)
model.fit(X_train_scaled, y_train)

Fitted_Models["Logistic"] = model

# y_pred = model.predict(X_test_scaled)
# confu_mat = confusion_matrix(y_test, y_pred)
# model_acc = accuracy_score(y_test, y_pred)
# print(confu_mat)
# print(model_acc)

#------------------------------------------------------------------------------


# Ridge Regression ------------------------------------------------------------

print("Ridge Regression")
model = GridSearchCV(estimator=LogisticRegression(penalty='l2',solver='saga'), param_grid=param_grid, cv=2)

model.fit(X_train_scaled,y_train)

Fitted_Models["Ridge"] = model

#------------------------------------------------------------------------------


# Lasso Regression ------------------------------------------------------------

print("Lasso Regression")

model = GridSearchCV(estimator=LogisticRegression(penalty='l1', solver='saga'), param_grid=param_grid, cv=n_cv)
model.fit(X_train_scaled,y_train)

Fitted_Models["Lasso"] = model

#------------------------------------------------------------------------------


# Elastic Net -----------------------------------------------------------------

print("Elastic Net")

param_grid = {'C': C_grid, 'l1_ratio':[0.90]}

model = GridSearchCV(estimator=LogisticRegression(penalty='elasticnet', solver='saga'), param_grid=param_grid, cv=n_cv)
model.fit(X_train_scaled,y_train)

Fitted_Models["Elastic Net"] = model

#------------------------------------------------------------------------------


# KNN -------------------------------------------------------------------------

print("KNN")

# param_grid = {'n_neighbors': list(range(2,25))}
param_grid = {'n_neighbors': [9]}

model = GridSearchCV(estimator=KNeighborsClassifier(), param_grid=param_grid, cv=n_cv, n_jobs=-1)
model.fit(X_train_scaled, y_train)

Fitted_Models["KNN"] = model

#------------------------------------------------------------------------------


# Random Forest ---------------------------------------------------------------

print("Random Forest")

# param_grid = {'max_depth': [2,3,4], 'n_estimators':[100,200,300], "min_samples_split": [1,2,3], "min_samples_leaf": [1,2,3]}
# param_grid = {'max_depth': [2,3,4,5,6], 'n_estimators':[100,200,300,400,500], "min_samples_split": [1,2,3,4,5], "min_samples_leaf": [1,2,3,4,5]}
# param_grid = {'max_depth': [2], 'n_estimators':[300], "min_samples_split": [3], "min_samples_leaf": [2]}

param_grid = {'max_depth': [2],
              'n_estimators':[10],
              "min_samples_split": [3],
              "min_samples_leaf": [3]
}

model = GridSearchCV(estimator=RandomForestRegressor(max_features='sqrt',random_state=1, n_jobs=-1),param_grid=param_grid, cv=n_cv)
model.fit(X_train_scaled, y_train)

Fitted_Models["Random Forest"] = model

#------------------------------------------------------------------------------


# Gradient Boosting -----------------------------------------------------------

print("Gradient Boosting")

# param_grid = {"n_estimators": [100,200,300], 'max_depth': [2,3,4], 'learning_rate': [0.01,0.001], "subsample": [0.10, 0.25, 0.5]}
# param_grid = {"n_estimators": [300,400,500,600], 'max_depth': [2,3,4], 'learning_rate': [0.5, 0.25, 0.1, 0.01], "subsample": [0.10]}
# param_grid = {"n_estimators": [800,1000], 'max_depth': [2], 'learning_rate': [0.01], "subsample": [0.10,0.25,0.5]}
# param_grid = {"n_estimators": [300], 'max_depth': [2], 'learning_rate': [0.001], "subsample": [0.10]}
# param_grid = {'learning_rate': [0.01,0.05,0.1],'n_estimators': [100],'max_depth': [2],'min_samples_split': [2,5,10],'min_samples_leaf': [1,2,4],'max_features': ['sqrt','log2',None]}
# param_grid = {'learning_rate': [0.01,0.05,0.1],'n_estimators': [100],'max_depth': [2],'min_samples_split': [2,5,10],'min_samples_leaf': [1,2,4],'max_features': ['sqrt','log2',None]}

param_grid = {'learning_rate': [0.05],
              'n_estimators': [100],
              'max_depth': [2],
              'min_samples_split': [10],
              'min_samples_leaf': [4],
              'max_features': ['sqrt'],
              'subsample':[0.5]
}

model = GridSearchCV(estimator=GradientBoostingRegressor(subsample=0.5, random_state=1),param_grid=param_grid, cv=n_cv)
model.fit(X_train_scaled, y_train)

Fitted_Models["G-Boosting"] = model  

#------------------------------------------------------------------------------


# XGBoost ---------------------------------------------------------------------

print("XGBoost")

# param_grid = {"n_estimators": [100,200,300], 'max_depth': [2,3,4], 'learning_rate': [0.01,0.001], "subsample": [0.25, 0.5, 0.75]}
# param_grid = {"n_estimators": [100], 'max_depth': [2], 'learning_rate': [0.001], "subsample": [0.5]}

param_grid = {
    'learning_rate': [0.0085],
    'max_depth': [2],
    'n_estimators': [100],
    'min_child_weight': [1],
    'subsample': [0.5],
}


model = GridSearchCV(estimator=xgb.XGBRegressor(subsample=0.5, random_state=1),param_grid=param_grid, cv=n_cv)
model.fit(X_train_scaled, y_train)

Fitted_Models["XGB"] = model

#------------------------------------------------------------------------------


# Decision Tree----------------------------------------------------------------

print("Decision Tree")

# param_grid = {'max_depth': [1,2,3],  "min_samples_split": [1,2,3], "min_samples_leaf": [1,2,3]}
param_grid = {'max_depth': [2],  "min_samples_split": [1], "min_samples_leaf": [3]}

model = GridSearchCV(estimator=DecisionTreeRegressor(random_state=1),param_grid=param_grid, cv=n_cv)
model.fit(X_train_scaled, y_train)

Fitted_Models["Decision Tree"] = model

#------------------------------------------------------------------------------


# Principal Component Regression ----------------------------------------------

print("PCR")

pipe = Pipeline([("pca", PCA()),
                  ("log", LogisticRegression(penalty=None))])
param_grid = [{"pca__n_components" : range(1,X_train_scaled.shape[1],int(np.ceil(X_train_scaled.shape[1]/10)))}]

pcr_cv = GridSearchCV(pipe, param_grid=param_grid, cv=5)
pcr_cv.fit(X_train_scaled, y_train)

Fitted_Models["PCR"] = model

#------------------------------------------------------------------------------


# Support Vector Regression ---------------------------------------------------

print("SVR")

# param_grid = {"C": C_grid, "kernel":["linear"]}
# param_grid = {
#     'C': [0.0001, 0.1, 1, 10],  # Penalty parameter C of the error term
#     'kernel': ['linear', 'poly', 'rbf', 'sigmoid'],  # Kernel type to be used in the algorithm
#     'degree': [2, 3, 4],  # Degree of the polynomial kernel function ('poly' only)
# }

param_grid = {"C":[0.1], "kernel":["linear"]}

model = GridSearchCV(estimator=SVC(),param_grid=param_grid, cv=n_cv)
model.fit(X_train_scaled, y_train)

Fitted_Models["SVR"] = model

#------------------------------------------------------------------------------

print("Finished: Create and Fit Models")


# =============================================================================
# Make Predictions
# =============================================================================

print("Starting: Make Predictions and Organize Results")

pred_list = {}

# Checks if Value are Binary, converts to Binary if not
for key, value in Fitted_Models.items():
    print(key)

    temp = value.predict(X_test_scaled)

    if not all(isinstance(x, int) for x in temp):
        threshold = 0.5
        temp2 = (temp  > threshold).astype(int)
        print(temp2)
        pred_list[key] = temp2
    else:
        pred_list[key] = temp


# pred_proba_list = {}

# # Checks if Value are Binary, converts to Binary if not
# for key, value in Fitted_Models.items():
#     print(key)

#     temp = value.predict_proba(X_test_scaled)[:,1]

print("Finished: Make Predictions and Organize Results")

# =============================================================================
# # Voting 
# =============================================================================
# Now that I have all my predictions, I'd like to create a model where majoritiy
# rules amoung the models.

print("Voting")

# Combine All Predictions into one DataFrame
poll = pd.DataFrame()
for value in pred_list.values():
    poll = pd.concat([poll,pd.Series(value)], axis=1)

# Majority Rules: 1 if most models decide 1 and zero otheriwse. Tiebreaker is just 1
# - Weren't very many ties however.
vote = pd.Series([1 if row.sum() >= (len(row) - row.sum()) else 0 for _, row in poll.iterrows()])

# Add to our list of predictions
pred_list["Vote"] = vote

# =============================================================================
# Make Scores
# =============================================================================

scores_list = {}

# Applys predict function to each of my values
for key, value in pred_list.items():
    y_pred = value

    confu_mat = confusion_matrix(y_test, y_pred)
    model_acc = accuracy_score(y_test, y_pred)
    
    scores_list[key] = confu_mat, model_acc

# =============================================================================
# Vizualize Confusion Matricies
# =============================================================================

# Define the class labels
class_names = ['Negative', 'Positive']

# Create the plot with the appropriate number of rows and columns
fig, axs = plt.subplots(nrows=4, ncols=3, figsize=(15, 25))

# Loop through each confusion matrix and create a plot
for i, key in enumerate(scores_list):
    row = i // 3
    col = i % 3
    matrix = scores_list[key][0]
    axs[row, col].matshow(matrix, cmap=plt.cm.Blues)
    
    for r in range(matrix.shape[0]):
        for c in range(matrix.shape[1]):
            axs[row, col].text(c, r, str(matrix[r, c]), va='center', ha='center')
    
    axs[row, col].set_xticklabels([''] + class_names)
    axs[row, col].set_yticklabels([''] + class_names)
    axs[row, col].set_xlabel('Predicted Label')
    axs[row, col].set_ylabel('True Label')
    axs[row, col].set_title(key)

# Hide unused subplots
for i in range(4 * 3 - len(scores_list)):
    axs[3, 2 - i].axis('off')

# Adjust the spacing between subplots
plt.subplots_adjust(hspace=0.35, wspace=0.35)

# Show the plot
plt.show()


# =============================================================================
# Create Rolling Week Benchmark
# =============================================================================

# Need to shift one week up
y_test_shifted = y_test.shift(-1)

# Take a rolling average of 3 weeks
y_pred_rolling_3 = y_test_shifted.rolling(window=3).mean()

# Create a new series with values of 1 or 0 based on the rolling average
y_pred_binary_3 = y_pred_rolling_3.apply(lambda x: 1 if x > 0.5 else 0)

# Replace any missing values with 0
y_pred_binary_3 = y_pred_binary_3.fillna(0)

# Drop Last Observation
y_pred_binary_3[:-1]

# Accuracy Score
benchmark_rolling_3 = accuracy_score(y_test, y_pred_binary_3)


# =============================================================================
# Vizualize Accuracy with Barplots
# =============================================================================

# Create a figure and axis object
fig, ax = plt.subplots()

# Create a bar plot
bar_width = 0.5
score = [value[1] for value in scores_list.values()]

ax.bar(scores_list.keys(), score, width=bar_width)

for i, (key, value) in enumerate(scores_list.items()):  
    # Add value on top of each bar (rounded)
    ax.text(key, value[1] + 0.1, f"{round(value[1]*100, 2)}", ha='center', fontsize=9)

# Set the title and axis labels
ax.set_xlabel('Models')
ax.set_ylabel('Score')

# Add space between bars
ax.set_xticks([i + bar_width/2 for i in range(len(scores_list))])

# Tilt the x-axis labels
ax.set_xticklabels(scores_list.keys(), rotation=45, ha='right')

# Scale the y-axis to be values from 0 to 1
ax.set_ylim([0, 1])

# Set the y-axis ticks to be displayed in increments of 0.1
ax.set_yticks([i/10 for i in range(11)])

# Add dashed lines for benchmarks
benchmark = y_test.value_counts()[0]/y_test.value_counts().sum()
label = f"Mean: {benchmark:.4f}"
ax.axhline(y=benchmark, color='gray', linestyle='--',label=label)
label2 = f"Rolling-3WK: {benchmark_rolling_3:.4f}"
ax.axhline(y=benchmark_rolling_3, color='gray', linestyle='--',label=label2)
ax.legend()

# Show the plot
plt.show()


# =============================================================================
# Store Best Parameters in a List
# ============================================================================

pd.Series(y_pred).value_counts()
y_test.value_counts()

best_params = {}

for key, values in Fitted_Models.items():
    print(values.best_estimator_)
    best_params[key] = str(values.best_estimator_)






