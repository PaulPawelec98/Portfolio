# -*- coding: utf-8 -*-
"""
Created on Thu Apr 27 13:40:00 2023

@author: Paul
"""

# =============================================================================
# Import Packages
# =============================================================================

import os
import csv

# =============================================================================
# Combine Data
# =============================================================================


def combine_csv_files(folder_path, output_path):
    # Get a list of all CSV files in the folder
    csv_files = [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith('.csv')]
    
    # Initialize a list to store all column names
    all_columns = []
    
    # Open the output file for writing
    with open(output_path, 'w', newline='', encoding='utf-8') as output_file:
        writer = csv.writer(output_file)
        
        # Loop through each CSV file and write its contents to the output file
        for file in csv_files:
            with open(file, 'r', encoding='utf-8') as input_file:
                reader = csv.reader(input_file)
                header = next(reader)
                
                # Add any new column names to the list of all column names
                for column in header:
                    if column not in all_columns:
                        all_columns.append(column)
                
                # Write the header row to the output file if it's the first file
                if csv_files.index(file) == 0:
                    writer.writerow(all_columns)
                
                # Loop through each row and write it to the output file
                for row in reader:
                    output_row = [row[header.index(column)] if column in header else '' for column in all_columns]
                    writer.writerow(output_row)
                    
    print('Combined CSV files have been saved to:', output_path)


folder_path = r'C:/Users/Paul/OneDrive - University of Guelph/Semester Folders/Semester 10/ECON 6600 - Labor Economics/Assignments/Ried'
output_path = r'C:/Users/Paul/OneDrive - University of Guelph/Semester Folders/Semester 10/ECON 6600 - Labor Economics/Assignments/combined.csv'
combine_csv_files(folder_path, output_path)