# -*- coding: utf-8 -*-
"""
Created on Tue Mar  7 00:29:18 2023

@author: Paul
"""

# Packages

import requests
from bs4 import BeautifulSoup
import urllib.request
from selenium.webdriver import Chrome
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select


# =============================================================================
# Initialize the webdriver
# =============================================================================

# Setup Driver ----------------------------------------------------------------
driver = webdriver.Chrome(executable_path='C:/Users/Paul/webdriver/chromedriver.exe')
#------------------------------------------------------------------------------

# Load the webpage
driver.get("http://odesi2.scholarsportal.info/webview/")
#------------------------------------------------------------------------------

# Wait for the page to load
driver.implicitly_wait(2)
#------------------------------------------------------------------------------

# =============================================================================
# Lists for Frames
# =============================================================================

# Lists of Frames we need to switch to ----------------------------------------
XPATH_SB_Menu = ["/html/frameset/frame[2]",\
                     '/html/frameset/frame[1]',\
                     '/html/frameset/frame[2]',\
                    ]

XPATH_TOP_Menu = ["/html/frameset/frame[2]",\
                    '/html/frameset/frame[2]',\
                    '/html/frameset/frame'
                    ]
#------------------------------------------------------------------------------
    
# =============================================================================
# Create Functions
# =============================================================================

def Switch_Frames(List):
    driver.switch_to.default_content()
    # Iterate over XPATHs to get to certain frame
    for frame in List:
        nest = driver.find_element(By.XPATH, frame)
        driver.switch_to.frame(nest)
        

def Find_LFS():       
    # List of Nodes I navigate through
    XPATH_List_Nodes = ['/html/body/div[13]/div[1]/ul/li/div/ul/li[14]/a[2]',\
                         '/html/body/div[13]/div[1]/ul/li/div/ul/li[14]/div/div/ul/li[1]/a[2]',\
                         '/html/body/div[13]/div[1]/ul/li/div/ul/li[14]/div/div/ul/li[1]/div/div/ul/li[16]/a[2]'\
                        ]      
        
    for node in XPATH_List_Nodes:
        driver.find_element(By.XPATH, node).click()
        

def Login_Microsoft():
    # start login process - first, uni site   
    # start login process - second, microsoft site
    
    # Switch Tabs
    print(driver.window_handles)
    driver.switch_to.window(driver.window_handles[1])
    driver.find_element(By.XPATH, '/html/body/div[3]/div/section[4]/div/div/div/div/div/div/div/form[1]/input[3]').click()
    driver.implicitly_wait(60) # Need to Manually login to Microsofts site

    # new_url = driver.current_url
    # print(new_url)
    # driver.get(new_url)
    # email_element = driver.find_element(By.XPATH, '/html/body/div/form[1]/div/div/div[2]/div[1]/div/div/div/div/div[1]/div[3]/div/div/div/div[2]/div[2]/div/input[1]')
    # email_element.send_keys("ppawelec@uoguelph.ca")
    # driver.find_element(By.XPATH, '/html/body/div/form[1]/div/div/div[2]/div[1]/div/div/div/div/div[1]/div[3]/div/div/div/div[4]/div/div/div/div/input')
    
    
def Download_LFS(First = False):
    # Starts the tedious process of downloading each file
    
    # switch to correct frame
    Switch_Frames(XPATH_TOP_Menu)
    
    driver.implicitly_wait(30)
    
    # find elements for download, set dropdown, and go to the uni of guelph
    driver.find_element(By.XPATH, '/html/body/div[2]/table/tbody/tr/td[15]/a').click() # downlaod button
    dropdown_element = driver.find_element(By.XPATH, '/html/body/div[8]/table[1]/tbody/tr/td[1]/form/select') # drop down button
    dropdown = Select(dropdown_element)
    dropdown.select_by_visible_text("Comma Separated Value file") # select data format
    driver.find_element(By.XPATH, '/html/body/div[8]/table[1]/tbody/tr/td[1]/form/label').click() # uncheck "include documentation"
    driver.find_element(By.XPATH, '/html/body/div[8]/table[1]/tbody/tr/td[2]/input[2]').click() # click download
    driver.find_element(By.XPATH, '/html/body/div[7]/div[3]/div/div/table/tbody/tr[11]/td[1]/a').click() # Will go to login for university

    if First == True:
        Login_Microsoft()
    else:
        driver.switch_to.window(driver.window_handles[1])
    
    # Reset to Top Menu Frame
    Switch_Frames(XPATH_TOP_Menu)
    
    # find elements for download, set dropdown, and go to the uni of guelph
    driver.find_element(By.XPATH, '/html/body/div[2]/table/tbody/tr/td[15]/a').click() # download button
    dropdown_element = driver.find_element(By.XPATH, '/html/body/div[8]/table[1]/tbody/tr/td[1]/form/select') # drop down button
    dropdown = Select(dropdown_element)
    dropdown.select_by_visible_text("Comma Separated Value file") # select data format
    driver.find_element(By.XPATH, '/html/body/div[8]/table[1]/tbody/tr/td[1]/form/label').click() # uncheck "include documentation"
    driver.find_element(By.XPATH, '/html/body/div[8]/table[1]/tbody/tr/td[2]/input[2]').click() # click download and downloads the file this time

    # Return to Previous Window
    driver.switch_to.window(driver.window_handles[0])


def Off_Campus_Login():
    # If you are logging into ODESI from off-campus, then you must login
    # via your university login for the first time for your session.
    
    # This just gets to the login page and downloads LFS data for 2023 January   
    Iterate_LFS("2020s", ["2023"], ["January"], True)
    
    
    
    
def Iterate_LFS(decade, years, months, FirstLogin=False):
    driver.find_element(By.XPATH, f"//*[contains(text(), '{decade}')]").click()

    for year in years:
        driver.find_element(By.XPATH, f"//*[@title='{year}']").click()
        for month in months:
            month_year = month + ' ' + str(year)
            driver.find_element(By.XPATH, f"//*[contains(text(), '{month_year}')]").click()
            Download_LFS(FirstLogin)
            Switch_Frames(XPATH_SB_Menu)


# =============================================================================
# Program Start
# =============================================================================

# Switch to Side Bar Menu
Switch_Frames(XPATH_SB_Menu)

# Find LFS box
Find_LFS()

# Login
Off_Campus_Login()

# Begin Downloading Data

# 2020s
# years  = [2022, 2021, 2020]
months = ['January',  \
          'February', \
          'March',    \
          'April',    \
          'May',      \
          'June',     \
          'July',     \
          'August',   \
          'September',\
          'October',  \
          'November', \
          'December'  \
         ]

# Iterate_LFS("2020s", years, months)

# 2010s
# years  = list(range(2010, 2010 + 10))
# Iterate_LFS("2010s", years, months)

# # 2000s
# years  = list(range(2000, 2000 + 10))
# Iterate_LFS("2000s", years, months)

# # 1990s
# years  = list(range(1990, 1990 + 10))
# Iterate_LFS("1990s", years, months)

# # 1980s
# years  = list(range(1980, 1980 + 10))
# Iterate_LFS("1980s", years, months)

# 1970s
years  = [1979]
Iterate_LFS("1970s", years, months)


# switch back to the main document object
driver.switch_to.default_content()
