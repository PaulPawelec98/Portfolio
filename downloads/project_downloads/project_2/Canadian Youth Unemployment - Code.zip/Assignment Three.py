# -*- coding: utf-8 -*-
"""
Created on Tue Feb 21 19:57:23 2023

@author: Paul
"""

# =============================================================================
#  Assignment Two
# =============================================================================


# Setup -----------------------------------------------------------------------
# Import packages, change directory.
import geopandas as gpd

import numpy as np
import pandas as pd
from datetime import datetime, date

import os

import statsmodels.formula.api as smf
from statsmodels.iolib.summary2 import summary_col
from rdd import rdd

import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib as mpl

path = "C:\\Users\\Paul\\OneDrive - University of Guelph\\Semester Folders\\Semester 10\\ECON 6600 - Labor Economics\\Assignments\\Assignment Three\\Data"
os.chdir(path)
del(path)
#------------------------------------------------------------------------------


# Functions -------------------------------------------------------------------
def grouped_weighted_avg(values, weights, by):
    # wieghted mean calculations with mutliple groupings and weights
    return pd.DataFrame((values * weights).groupby(by).sum() / weights.groupby(by).sum())
#------------------------------------------------------------------------------


# Load Data --------------------------------------------------------------------
# Load cleaned CSV for LFS
df = pd.read_csv("combined_cleaned.csv", encoding='latin-1')

# Load Min_Wage Data
file_path = "C:\\Users\\Paul\\OneDrive - University of Guelph\\Semester Folders\\Semester 10\\ECON 6600 - Labor Economics\\Assignments\\Assignment Three\\Data\\Government Data"
min_wage = pd.read_csv(file_path+"\\min_wage.csv")
del(file_path)
#------------------------------------------------------------------------------


# Clean Data ------------------------------------------------------------------

# Drop LFSTAT
df = df.drop("LFSSTAT", axis=1)

# Drop Index
df = df.drop('Unnamed: 0', axis=1)

# Sort df by Date
df = df.sort_values('Date', ascending=True)

# Clean min_wage
min_wage = min_wage.drop_duplicates(subset=['Jurisdiction', 'Date'], keep='last')

min_wage['Date'] = pd.to_datetime(min_wage['Date'], format='%d-%b-%y')

min_wage = min_wage[min_wage['Date'] <= "2023-01-01"]
min_wage = min_wage[min_wage['Date'] >= "1976-01-01"]
min_wage = min_wage.sort_values(by=["Jurisdiction", "Date"])

# Return Unique Provinces
provinces = list(pd.unique(df["PROV"]))
provinces.append("Federal")

# Replace Newfoundland and Labrador to Newfoundland
min_wage['Jurisdiction'] = min_wage['Jurisdiction'].replace({'Newfoundland and Labrador': 'Newfoundland'})

# Drop observations that don't match the items in the list
min_wage = min_wage[min_wage['Jurisdiction'].isin(provinces)]

#------------------------------------------------------------------------------


# Create New Data Sets --------------------------------------------------------
data_by_prov = {}

for prov in provinces[0:-1]:
    data_by_prov[prov] = df[df['PROV'] == prov]
#------------------------------------------------------------------------------


# Summary Statistics ----------------------------------------------------------

grouped_weighted_avg(df["unemployed"], df['FWEIGHT'], [df["PROV"], df["SURVYEAR"]])


stats1 = df.groupby(['PROV'])[['AGE_12']].describe().iloc[:,0:1]
stats2 = df.groupby(['PROV'])[['unemployed']].describe().iloc[:,1:2]
summary_stats = pd.merge(stats1, stats2, left_index=True, right_index=True)

stats3 = df.groupby(['PROV', "SURVYEAR"])[['unemployed']].describe().iloc[:,1:2]

# Reset index
stats3 = stats3.reset_index()

# Remove the second level of the column header
stats3.columns = stats3.columns.droplevel(1)

# Create line plot with larger scale
plt.figure(figsize=(14, 8))

# Create line plot
sns.lineplot(data=stats3, x='SURVYEAR', y='unemployed', hue='PROV')

# Add a legend to the plot
plt.legend(loc='center left', bbox_to_anchor=(1.0, 0.5), fontsize="small")

# Show the chart
plt.show()

#------------------------------------------------------------------------------
    

# Regressions -----------------------------------------------------------------

results = {}

for key in provinces[0:-1]:
    results[key] = []

for index, row in min_wage.iterrows():
    if row[0] == "Federal":
        continue
    else:
        pass
    
    temp = data_by_prov[row[0]]
    cutoff_date = row[1]
    running_var = temp['Date']

    print(row[0])
    print(cutoff_date)
    
    # Convert running variable to datetime
    running_var = pd.to_datetime(running_var, format='%Y-%m')
    
    # Convert cutoff date to datetime
    cutoff_date = pd.to_datetime(cutoff_date, format='%Y-%m-%d')

    # Create distance-to-cutoff variable
    distance_to_cutoff = (running_var - cutoff_date) / 30
    distance_to_cutoff = distance_to_cutoff.astype('timedelta64[D]').astype(int)
    
    data = np.array([distance_to_cutoff.values, temp['unemployed']]).T
    data = pd.DataFrame(data)
    data.columns  = ["Date", "unemployed"]

    coef = []    

    

    for value in list(range(1,7)):
        data_rdd1 = rdd.truncated_data(data, 'Date', value)
        model1_1 = rdd.rdd(data_rdd1, 'Date', 'unemployed', cut=0)
        coef.append(model1_1.fit().params[1])
        
    result = [cutoff_date, row[2]] + coef
    results[row[0]].append(result)

results2 = {}

for key in provinces[0:-1]:
    results2[key] = []

for index, row in min_wage.iterrows():
    if row[0] == "Federal":
        continue
    else:
        pass
    
    temp = data_by_prov[row[0]]
    cutoff_date = row[1]
    running_var = temp['Date']

    print(row[0])
    print(cutoff_date)
    
    # Convert running variable to datetime
    running_var = pd.to_datetime(running_var, format='%Y-%m')
    
    # Convert cutoff date to datetime
    cutoff_date = pd.to_datetime(cutoff_date, format='%Y-%m-%d')

    # Create distance-to-cutoff variable
    distance_to_cutoff = (running_var - cutoff_date) / 30
    distance_to_cutoff = distance_to_cutoff.astype('timedelta64[D]').astype(int)
    
    data = np.array([distance_to_cutoff.values, temp['unemployed']]).T
    data = pd.DataFrame(data)
    data.columns  = ["Date", "unemployed"]

    coef = []    

    

    for value in list(range(1,7)):
        data_rdd1 = rdd.truncated_data(data, 'Date', value)
        model1_1 = rdd.rdd(data_rdd1, 'Date', 'unemployed', cut=0)
        coef.append(model1_1.fit().tvalues[1])
        
    result = [cutoff_date, row[2]] + coef
    results2[row[0]].append(result)

#------------------------------------------------------------------------------


# Create Table ----------------------------------------------------------------

table1 = pd.DataFrame()

for state, values in results.items():
    for i, value in enumerate(values):
        comb = pd.DataFrame([state] + value).T
        table1 = pd.concat([table1,comb])

table1 = table1.sort_values([0,1])

table1.columns = ["Jurisdiction", "Cutoff", "Min Wage"] + [f"{num} month" for num in range(1, 7)]
table1 = table1.fillna(0)

condition = table1.iloc[:,3:] > 1
table1.loc[condition.any(axis=1),'1 month'] = 0

# Average Unemployment Per Jurisdiction
table2 = table1.groupby("Jurisdiction")[[f"{num} month" for num in range(1, 7)]].mean()

table3 = pd.DataFrame()

for state, values in results2.items():
    for i, value in enumerate(values):
        comb = pd.DataFrame([state] + value).T
        table3 = pd.concat([table3,comb])

table3 = table3.sort_values([0,1])

table3.columns = ["Jurisdiction", "Cutoff", "Min Wage"] + [f"{num} month" for num in range(1, 7)]
table3 = table3.fillna(0)

# These were off in prior table and replaced with 0, I'll do the same here for consistency.
condition = table1.iloc[:,3:] > 1
table3.loc[condition.any(axis=1),'1 month'] = 0

# counts = table3[table3[[f"{num} month" for num in range(1, 7)]].abs() > 2].groupby('Jurisdiction').size()

counts = (table3[[f"{num} month" for num in range(1, 7)]] > 2).astype(int)

# Average of T-Values over 2 
table4 = pd.concat((pd.DataFrame(table3.iloc[:,0:3]), counts), axis=1).groupby("Jurisdiction").mean()

#------------------------------------------------------------------------------


# Scatter Plot (Everything) ---------------------------------------------------

# create a 2x3 grid of subplots
fig, axes = plt.subplots(nrows=3, ncols=2, figsize=(18, 24))
months = [f"{num} month" for num in range(1, 7)]

# increase the font size
mpl.rcParams.update({'font.size': 20})

for month, ax in zip(months, axes.flatten()):
    
    # Create Style Markers
    style = table3[month] > 2
    markers = {True: '^', False: 'v'}
    
    # calculate percentage of points above 0 for a specific column
    column_name = month
    above_threshold = table1[table1[month] > 0]
    percentage_above_threshold = (len(above_threshold) / len(table1)) * 100
    
    # Calculate Percentage of Points Above 0 and Significant
    above_threshold_significant = (table1[month] > 0).astype(int) * style.astype(int)
    percentage_above_threshold_significant = (above_threshold_significant.sum() / len(table1)) * 100
    
    # Calculate Percentage of Points Below 0 and Significant
    below_threshold_significant = (table1[month] < 0).astype(int) * style.astype(int)
    percentage_below_threshold_significant = (below_threshold_significant.sum() / len(table1)) * 100
    
    # Create the scatter plot using Seaborn
    sns.scatterplot(data=table1, x='Cutoff', y=month, hue='Jurisdiction', ax=ax, style=style ,markers=markers)
    
    # Add text box to the subplot
    threshold = 0
    ax.text(0.98, 0.06, f"{percentage_above_threshold_significant:.2f}% of '{column_name}' points are above {threshold} and significant", ha='right', va='bottom', transform=ax.transAxes, fontsize=12)
    ax.text(0.98, 0.11, f"{percentage_above_threshold:.2f}% of '{column_name}' points are above {threshold}", ha='right', va='bottom', transform=ax.transAxes, fontsize=12)
    ax.text(0.98, 0.01, f"{percentage_below_threshold_significant:.2f}% of '{column_name}' points are below {threshold} and significant", ha='right', va='bottom', transform=ax.transAxes, fontsize=12)

    # Rotate the x-axis tick labels
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45)
    
    # add a horizontal line at y=0.3
    ax.axhline(y=0, color='grey', linestyle='--')
    
    # Add ylimit
    ax.set_ylim(-0.3, 0.3)
    
    # Rename y
    ax.set_ylabel("Treatment")
    
    # Show the plot
    ax.set_title(month)
    
    # Remove the legend for each subplot
    ax.get_legend().remove()

# Create the legend separately
handles, labels = ax.get_legend_handles_labels()
labels.remove('6 month')
fig.legend(handles, labels, bbox_to_anchor=(1.25, 0.62))

# adjust the layout of the subplots
plt.tight_layout()

# Increase the dpi to make the image sharper
plt.savefig('plot2.png', dpi=300, bbox_inches='tight')

# show the plot
plt.show()

#------------------------------------------------------------------------------


# Scatter Plot (1 month) ------------------------------------------------------

# Create Style Markers
month = '1 month'

style = table3[month] > 2
markers = {True: '^', False: 'v'}

# calculate percentage of points above 0 for a specific column
column_name = month
above_threshold = table1[table1[month] > 0]
percentage_above_threshold = (len(above_threshold) / len(table1)) * 100

# Calculate Percentage of Points Above 0 and Significant
above_threshold_significant = (table1[month] > 0).astype(int) * style.astype(int)
percentage_above_threshold_significant = (above_threshold_significant.sum() / len(table1)) * 100

# Calculate Percentage of Points Below 0 and Significant
below_threshold_significant = (table1[month] < 0).astype(int) * style.astype(int)
percentage_below_threshold_significant = (below_threshold_significant.sum() / len(table1)) * 100

# Set Size
fig, ax = plt.subplots(figsize=(12, 8))

# Create the scatter plot using Seaborn
ax = sns.scatterplot(data=table1, x='Cutoff', y=month, hue='Jurisdiction', style=style, markers=markers)

# move the legend to the right and outside the plot
plt.legend(bbox_to_anchor=(1.02, 1), loc='upper left', borderaxespad=0)

# Remove the legend for each subplot
ax.get_legend().remove()

# Add text box to the subplot
threshold = 0
ax.text(0.98, 0.06, f"{percentage_above_threshold_significant:.2f}% of '{column_name}' points are above {threshold} and significant", ha='right', va='bottom', transform=ax.transAxes, fontsize=12)
ax.text(0.98, 0.11, f"{percentage_above_threshold:.2f}% of '{column_name}' points are above {threshold}", ha='right', va='bottom', transform=ax.transAxes, fontsize=12)
ax.text(0.98, 0.01, f"{percentage_below_threshold_significant:.2f}% of '{column_name}' points are below {threshold} and significant", ha='right', va='bottom', transform=ax.transAxes, fontsize=12)

# Rotate the x-axis tick labels
ax.set_xticklabels(ax.get_xticklabels(), rotation=45)

# add a horizontal line at y=0.3
ax.axhline(y=0, color='grey', linestyle='--')

# Create the legend separately
handles, labels = ax.get_legend_handles_labels()
labels.remove('1 month')
fig.legend(handles, labels, bbox_to_anchor=(1.25, 0.8))

# Add ylimit
ax.set_ylim(-0.3, 0.3)

# Rename y
ax.set_ylabel("Treatment")

# Show the plot
ax.set_title(month)

# Increase the dpi to make the image sharper
plt.savefig('plot3.png', dpi=300, bbox_inches='tight')

plt.show()
#------------------------------------------------------------------------------


# Export Summary Statistics and Regression Results to LaTex -------------------

# Round
summary_stats = summary_stats.round(2)
table2 = table2.round(3)
table4 = table2.round(3)

# Regression Results are too Large, so I don't think I'll export? Maybe
# Appendix?

summary_stats.to_latex("table1.tex")
table2.to_latex("table2.tex")
table4.to_latex("table3.tex")
#------------------------------------------------------------------------------


# =============================================================================
# End of Script
# =============================================================================