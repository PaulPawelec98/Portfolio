# -*- coding: utf-8 -*-
"""
Created on Tue Apr 25 16:42:59 2023

@author: Paul
"""

# =============================================================================
# Explore Data
# =============================================================================

# Setup -----------------------------------------------------------------------
# Import packages, change directory.
import numpy as np
import pandas as pd
import os
import csv
import glob
import zipfile

folder_path = "C:\\Users\\Paul\\OneDrive - University of Guelph\\Semester Folders\\Semester 10\\ECON 6600 - Labor Economics\\Assignments\\Assignment Three\\Data\\LFS Data"
#------------------------------------------------------------------------------

# # Iterate through all the CSV files in the folder -----------------------------
# for file_name in os.listdir(folder_path):
#     if file_name.endswith('.csv'):
#         file_path = os.path.join(folder_path, file_name) # Create filepath to actual file
        
#         # Read the headers from the CSV file
#         with open(file_path, 'r') as csv_file:
#             csv_reader = csv.reader(csv_file)
#             headers = pd.Series(next(csv_reader))
            
                
# # Print the dataframe
# print(df)

# df.to_csv("headers.csv")


# for file_name in os.listdir(folder_path):
#     if file_name.endswith('.csv'):
#         file_path = os.path.join(folder_path, file_name)


os.chdir(folder_path)
#------------------------------------------------------------------------------


# =============================================================================
# Extract from zip Files
# =============================================================================
# create a list of all the zip files in the directory -------------------------
zip_files = glob.glob("*.zip")
#------------------------------------------------------------------------------


# extract all the csv files from each zip file --------------------------------
# csv_files = []
# for zip_file in zip_files:
#     with zipfile.ZipFile(zip_file, 'r') as zip_ref:
#         zip_ref.extractall()
#         csv_files += glob.glob("*.csv")
#------------------------------------------------------------------------------ 

    
# =============================================================================
# Clean
# =============================================================================

# These are the one-one columns that should be the same in data1
cols = ["LFSSTAT","SURVYEAR", "SURVMNTH", "PROV",
        "AGE_12", "FWEIGHT"]


df = pd.DataFrame(columns=cols)

# Grab and Create Columns for New Data Set ------------------------------------

# Loop through all files in folder
for filename in os.listdir(folder_path):
    if filename.endswith(".csv"):
        
        # Read each file and apply the same processing steps
        file_path = os.path.join(folder_path, filename)
        
        chunk = pd.read_csv(file_path)
        
        # Check for FINALWT and FWEIGHT
        if "FINALWT" in chunk.columns:
            temp = ["LFSSTAT","SURVYEAR", "SURVMNTH", "PROV",
                    "AGE_12", "FINALWT"]
            
            chunk = chunk.loc[:,temp]
            chunk = chunk.rename(columns={'FINALWT': 'FWEIGHT'})

        elif "FWEIGHT" in chunk.columns:
            chunk = chunk.loc[:,cols]
        
        
        if chunk['SURVYEAR'][0] > 2016:
            # Drop Indivuduals that are not in the labor force
            chunk = chunk[(chunk['LFSSTAT'] != 4)]
        else:
            # Drop Indivuduals that are not in the labor force
            chunk = chunk[(chunk['LFSSTAT'] != 6)]
        
        # Create unemployed variable
        chunk["unemployed"] = [0 if (row == 1) | (row == 2) else 1 for row in chunk["LFSSTAT"]]
    
        # Only Want Youths (15 to 29)
        chunk = chunk[(chunk['AGE_12'] ==  1)]
        
        # Create Data Column
        chunk["Date"] = pd.to_datetime(chunk['SURVYEAR'] * 10000 + chunk['SURVMNTH'] * 100 + 1, format='%Y%m%d')
        
        
        # Replace values for actual for PROV
        num_to_prov = {10:"Newfoundland",\
                       11:"Prince Edward Island",\
                       12:"Nova Scotia",\
                       13:"New Brunswick",\
                       24:"Quebec",\
                       35:"Ontario",\
                       46:"Manitoba",\
                       47:"Saskatchewan",\
                       48:"Alberta",\
                       59:"British Columbia",\
                       }
        
        chunk['PROV'] = chunk['PROV'].replace(num_to_prov)
        
        # Replace values for actual for AGE_12
        num_to_age = {1: "15 to 19",\
                    2: "20 to 24",\
                    3: "25 to 29",\
                    4: "30 to 34",\
                    5: "35 to 39",\
                    6: "40 to 44",\
                    7: "45 to 49",\
                    8: "50 to 54",\
                    9: "55 to 59",\
                    10: "60 to 64",\
                    11: "65 to 69",\
                    12: "70 or more"\
                    }
            
        chunk['AGE_12'] = chunk['AGE_12'].replace(num_to_age)
        
        # Append to df
        df = pd.concat([df, chunk])  
        
        # Print
        print(filename)
        print(chunk.head(1))
    
df.to_csv("combined_cleaned.csv")
    
    
# df = pd.read_csv("combined.csv", chunksize=chunksize)
# df = pd.DataFrame(df)

