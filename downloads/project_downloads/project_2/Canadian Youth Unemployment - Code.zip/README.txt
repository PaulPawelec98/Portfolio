#========================================
Canadian Youth Unemployment
#========================================

Author: Paul Pawelec
Date: 2023

#========================================
Files Included in Order of Execution
#========================================

1. LFS_Pull.py
2. LFS_Clean.py
3. LFS_Combine.py
4. Assignment Three.py

#========================================
Notes
#========================================

 - LFS_Pull will not work unless you have
   a student account at one of the univer-
   sities listed on the site.
  
#========================================
End of README
#========================================